package com.tu.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tu.cloudstack.api.cloudstack_api;
import com.tu.dto.BillingDTO;
import com.tu.dto.InstanceDTO;
import com.tu.dto.LicenseDTO;
import com.tu.dto.MemberVO;
import com.tu.dto.ProductDTO;
import com.tu.dto.apiDTO;
import com.tu.dto.loginDTO;
import com.tu.service.ApiService;
import com.tu.service.BillingService;
import com.tu.service.InstanceService;
import com.tu.service.LicenseService;
import com.tu.service.MemberService;
import com.tu.service.ProductService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@SuppressWarnings("unused")
	private String signature;

	@Inject
	private MemberService service;

	@Inject
	private ApiService api_service;

	@Inject
	private LicenseService license_service;

	@Inject
	private InstanceService instance_service;

	@Autowired
	private BillingService billing_service;

	@Inject
	private ProductService product_service;

	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		// HttpSession session = arg

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "admin/index";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Locale locale, Model model) throws Exception {
		logger.info("Welcome home! The client locale is {}.", locale);

		return "login";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String regist(Model model) throws Exception {
		return "register";
	}

	@RequestMapping(value = "/registPost", method = RequestMethod.POST)
	public String register(Model model, MemberVO member) throws Exception {
		System.out.println(member.getUserName());
		service.insertMember(member);
		return "redirect:/login";
	}

	@RequestMapping(value = "/loginPost", method = RequestMethod.POST)
	public String loginPost(Model model, HttpServletRequest request, HttpServletResponse response, loginDTO dto,
			HttpSession session) throws Exception {
		// System.out.println("loginPost...........start");
		// System.out.println(dto.getUserEmail() + "," + dto.getUserPwd());
		System.out.println("login입니다.");
		if (service.selectMember(dto) != null) {

			// 이민재 추가함 start
			apiDTO apikey = null;
			String command = "login";
			//String param = "&username=admin" + "&password=password";
			String param = "&username=om-admin" + "&password=qwer4321!!";
			System.out.println(command + param);
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.postLogin(command + param, session);

			System.out.println(output);

			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("loginresponse");

			MemberVO vo = service.selectMember(dto);
			session.setAttribute("username", vo.getUserName());
			session.setAttribute("isadmin", vo.getIsadmin());

			// 정영현 추가함 start
			session.setAttribute("useremail", vo.getUserEmail());
			// 정영현 추가함 end

			/* session.setMaxInactiveInterval(60*60*12); */
			System.out.println(vo.getUserName() + ", " + vo.getIsadmin());

			// loginlog db에 기록
			service.insertLoginLog(vo.getUserEmail());

			return "redirect:/";
		} else {
			model.addAttribute("flag", "false");
			return "redirect:/login";
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(Model model, HttpSession session) throws Exception {
		System.out.println("logout");
		session.setAttribute("username", null);
		session.setAttribute("isadmin", null);

		// 정영현 추가함 start
		session.setAttribute("useremail", null);
		// 정영현 추가함 end

		// 이민재 추가함 start
		apiDTO apikey = null;
		String command = "logout";
		System.out.println(command);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.postLogout(command, session);

		System.out.println(output);

		session.invalidate();
		return "redirect:/";
	}

	// mypage,modify,regsiter 추가 부분, 정영현 start
	// Form에서 action으로 들어온건 method=RequestMethod.POST가 되는데(method="post")로 해서, href는
	// POST가 안된다., GET으로 해야 됨. 보안을 높이려면 FORM을 줘야된다는 소리네
	@RequestMapping(value = "/mypage", method = RequestMethod.GET)
	public String mypage(Model model, HttpSession session) throws Exception {
		System.out.println("mypage입니다.");
		String email = (String) session.getAttribute("useremail");
		System.out.println("email : " + email);
		MemberVO vo = service.selectMemberByEmail(email);
		model.addAttribute("memberDto", vo);
		return "mypage";
	}

	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String modify(Model model, HttpSession session, MemberVO vo) throws Exception {
		model.addAttribute("memberDto", vo);

		// 번호는 tab으로 분리해서 따로 넘길것
		String mobile = vo.getUserMobile();
		String phone = vo.getUserPhone();
		String fax = vo.getUserFax();

		String[] mobileArr = mobile.split("\t");
		String[] phoneArr = phone.split("\t");
		String[] faxArr = fax.split("\t");

		// 배열이 제대로 생성되었는지 길이값으로 체크,
		// 이렇게 하니깐 제대로 되더라 tab 사이에 인자가 몇번째에 있는지에 따라서 array length 결정됨 확인 했음
		String userMobile1 = mobileArr.length < 1 ? "" : mobileArr[0];
		String userMobile2 = mobileArr.length < 2 ? "" : mobileArr[1];
		String userMobile3 = mobileArr.length < 3 ? "" : mobileArr[2];

		String userPhone1 = phoneArr.length < 1 ? "" : phoneArr[0];
		String userPhone2 = phoneArr.length < 2 ? "" : phoneArr[1];
		String userPhone3 = phoneArr.length < 3 ? "" : phoneArr[2];

		String userFax1 = faxArr.length < 1 ? "" : faxArr[0];
		String userFax2 = faxArr.length < 2 ? "" : faxArr[1];
		String userFax3 = faxArr.length < 3 ? "" : faxArr[2];

		model.addAttribute("userMobile1", userMobile1);
		model.addAttribute("userMobile2", userMobile2);
		model.addAttribute("userMobile3", userMobile3);

		model.addAttribute("userPhone1", userPhone1);
		model.addAttribute("userPhone2", userPhone2);
		model.addAttribute("userPhone3", userPhone3);

		model.addAttribute("userFax1", userFax1);
		model.addAttribute("userFax2", userFax2);
		model.addAttribute("userFax3", userFax3);

		return "modify";
	}

	@RequestMapping(value = "/checkCurrentPwd", method = RequestMethod.POST)
	public void checkCurrentPwd(HttpServletResponse response, loginDTO dto) throws Exception {
		PrintWriter out = response.getWriter();
		String output = "";
		if (service.selectMember(dto) == null) {
			// 로그인 정보 없으면 current password 값 틀린 것
			output = "false";
		} else {
			// current password 맞음
			output = "true";
		}
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/modifyPost", method = RequestMethod.POST)
	public String modifyPost(Model model, MemberVO member, HttpSession session) throws Exception {
		// System.out.println("modifyPost username : " + member.getUserName());

		if (member.getUserPwd() == null || member.getUserPwd().trim() == "") {
			// 한페이지에서 일괄처리 해주려니깐 비번이 넘어오고 안넘어오고가 중요하다
			// 그래서 udpate 문을 두개로 가야 된다.
			// userpwd 값이 없으면 비밀번호 제외하고 update
			service.updateMemberExcPwd(member); // db에서 update된 값 가져오기,, 값이 같을 거지만\
		} else {
			// userpwd 값이 같이 넘어왔으면 update를 일괄적으로 해주고
			service.updateMember(member); // db에서 update된 값 가져오기,, 값이 같을 거지만\
		}

		// model.addAttribute("memberDto",updateMember); // Update로 Select 효과도 가져올수
		// 있네(mapper.xml에서 이거해주면 resultType="com.tu.dto.MemberVO")
		// mapper.xml resultType 방법대로 해서 아래와 같이 하면
		// updateMember = service.updateMemberExcPwd(member); 이렇게 사용하니깐
		// updateMember.getUserName() 이거 에러남
		// 근데 mypage.jsp에서는 에러 안남.... 그냥 정석대로 가자

		String userEmail = (String) session.getAttribute("useremail");
		MemberVO updateMember = service.selectMemberByEmail(userEmail);

		// username 은 변경될수가 있어서 (다른값들 setAttribute 안해주면 사라지는지 확인해봐)
		session.setAttribute("username", updateMember.getUserName());

		return "redirect:/mypage";
	}

	@RequestMapping(value = "/checkUserEmail", method = RequestMethod.POST)
	public void checkUserEmail(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String userEmail = request.getParameter("userEmail");

		PrintWriter out = response.getWriter();
		String output = "";
		if (service.selectMemberByEmail(userEmail) != null) {
			// 이건 값이 있으면 false
			output = "false";
		} else {
			// 이건 값이 없으면 true
			output = "true";
		}
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/findEmailPost", method = RequestMethod.POST)
	public void findEmailPost(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String userName = request.getParameter("userName");
		String userBirth = request.getParameter("userBirth");

		PrintWriter out = response.getWriter();

		ArrayList<MemberVO> arrayVo = service.selectMemberByInfo(userName, userBirth);

		JSONObject outputObject = new JSONObject();

		String[] output = new String[arrayVo.size()];
		for (int i = 0; i < arrayVo.size(); i++) {
			output[i] = arrayVo.get(i).getUserEmail();
			outputObject.append("email", output[i]); // 같은 네임으로 append 하니깐 사용할수 잇네
		}

		// outputObject.append("email", output); // Array를 append해주면 2중어레이로 쓰기 불편함
		out.print(outputObject);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/findPwd", method = RequestMethod.GET)
	public String findPwd(Locale locale) throws Exception {
		logger.info("findPwd");
		return "findPwd";
	}

	@RequestMapping(value = "/emailValidCheck", method = RequestMethod.POST)
	public void emailValidCheck(Locale locale, HttpServletResponse response, HttpServletRequest request)
			throws Exception {
		// logger.info("emailValidCheck");
		PrintWriter out = response.getWriter();
		String output = "";
		String email = (String) request.getParameter("userEmail");
		MemberVO vo = service.selectMemberByEmail(email);
		if (vo != null) {
			output = "true";
		} else {
			output = "false";
		}
		out.print(output);
		out.flush();
		out.close();
	}

	/*
	 * @RequestMapping(value="/mypagePost", method=RequestMethod.POST) public String
	 * mypagePost(Model model, HttpSession session, MemberVO vo) throws Exception {
	 * System.out.println("userEmail : " + vo.getUserEmail());
	 * model.addAttribute("memberDto", vo); return "redirect:/modify"; // 이렇게 해야지
	 * 주소값이 mypagePost에서 아래 method 를 타고 modify 로 변경됨 // redirect:/ 는
	 * 반드시 @RequestMapping 값이 mapping되어야 한다. 안그럼 없다고 뜬다. }
	 * 
	 * @RequestMapping(value="/modify", method=RequestMethod.GET) public String
	 * modify(Model model) throws Exception {
	 * 
	 * return "modify"; // 이렇게 해야지 주소값을 modify 로 나타낸다. 근데 이건 비효율 적인듯, 값을 넘겨줄 방법이 없다.
	 * }
	 */

	// mypage,modify,regsiter 추가 부분, 정영현 end

	@RequestMapping(value = "/apitest", method = RequestMethod.POST)
	public void apitest(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("apitest");
		String command = request.getParameter("test"); // listAlerts 값 넘어옴
		System.out.println("command : " + command);
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		// System.out.println("apitest output pre output");
		String output = api.getResultFromRequest(command, session);
		// String url = api.get_url();
		System.out.println("apitest output value : " + output);
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiCapa", method = RequestMethod.POST)
	public void apiCapa(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_Capacity");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String str = "listCapacity";
		String output = api.getResultFromRequest(str, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiStopVM", method = RequestMethod.POST)
	public void apiStopVM(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_Stop VM");
		String command = request.getParameter("test");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiStartVM", method = RequestMethod.POST)
	public void apiStartVM(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_Start VM");
		String command = request.getParameter("test");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiRebootVM", method = RequestMethod.POST)
	public void apiRebootVM(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_Reboot VM");
		String command = request.getParameter("test");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiCheckDuplInstanceName", method = RequestMethod.POST)
	public void apiCheckDuplInstanceName(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiCheckDuplInstanceName");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("command");
		String name = request.getParameter("name");

		command += "&name=" + name; // name에 - 있으면 잘 못가져오니깐 따로 para 값 줌

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiNewInstancePost", method = RequestMethod.POST)
	public void apiNewInstancePost(Locale locale, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("apiNewInstancePost");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String command = request.getParameter("command");
		String name = request.getParameter("name");
		String group = request.getParameter("group");
		String userdata = request.getParameter("userdata");

		// name 무조건 있으니깐
		command += "&name=" + name + "&displayname=" + name;

		if (group != "") {
			command += "&group=" + group;
		}

		Encoder encode = Base64.getEncoder();
		byte[] bytes = userdata.getBytes();
		String encodeuserdata = encode.encodeToString(bytes);

		if (userdata != "") { // userdata 가 공란이 아니면 encoding 한거 넣기
			command += "&userdata=" + encodeuserdata;
		}

		System.out.println("command : " + command);

		String output = api.getResultFromRequest(command, session);

		System.out.println("output : " + output);
		// 신규생성되면 'output :
		// {"deployvirtualmachineresponse":{"id":"4497e8ce-40bf-4fd0-a44c-2d315489ed7e","jobid":"12cc9434-a61f-4930-b4a7-7d0864b8245c"}}'
		// 중복이면 'output : connection failed.' 왜 fail 됐는지 모르니깐 그전에 걸러줄것

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiDestroyVM", method = RequestMethod.POST)
	public void apiDestroyVM(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiDestroyVM");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("test");

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiRecoverVM", method = RequestMethod.POST)
	public void apiRecoverVM(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiRecoverVM");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("test");

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiExpungeVM", method = RequestMethod.POST)
	public void apiExpungeVM(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiExpungeVM");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("test");

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiReinstallVM", method = RequestMethod.POST)
	public void apiReinstallVM(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiReinstallVM");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("test");

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiDeleteSnapshot", method = RequestMethod.POST)
	public void apiDeleteSnapshot(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiDeleteSnapshot");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id = request.getParameter("vmsnapshotid");
		String command = "deleteVMSnapshot&vmsnapshotid=" + id;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiRevertToVMSnapshot", method = RequestMethod.POST)
	public void apiRevertSnapshot(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiRevertToVMSnapshot");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id = request.getParameter("vmsnapshotid");
		String command = "revertToVMSnapshot&vmsnapshotid=" + id;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiSnapshotsContents", method = RequestMethod.POST)
	public void apiSnapshotsContents(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiSnapshotsContents");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String snapshotid = request.getParameter("snapshotid");
		String command = "listVMSnapshot&listall=true&vmsnapshotid=" + snapshotid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiQueryAsyncJobResult", method = RequestMethod.POST)
	public void apiQueryAsyncJobResult(Locale locale, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws IOException {
		logger.info("apiQueryAsyncJobResult");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("test");

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/users", method = RequestMethod.GET)
	public String users(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to users");
		apiDTO apikey = null;
		String command = "listAccounts&listall=true";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		System.out.println("output : " + output);

		JSONObject obj = new JSONObject(output);

		// obj = obj.getJSONObject("user");
		// System.out.println("user obj : " + obj);

		obj = obj.getJSONObject("listaccountsresponse");
		System.out.println("listusersresponse obj : " + obj);
		JSONArray arr = (JSONArray) obj.get("account");
		System.out.println("arr : " + arr);
		model.addAttribute("accountlist", arr);
		return "admin/users";
	}

	@RequestMapping(value = "/admin/usersContents", method = RequestMethod.POST)
	public String usersContents(Locale locale, Model model, HttpServletRequest request, HttpSession session)
			throws Exception {
		logger.info("go to users");
		apiDTO apikey = null;
		String command = "listUsers";
		String userid = request.getParameter("userid");
		command += "&id=" + userid;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		JSONObject userObj = null;
		try {
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listusersresponse");
			JSONArray arr = (JSONArray) obj.get("user");
			userObj = arr.getJSONObject(0);
		} catch (Exception e) {
			// TODO: handle exception
		}

		// System.out.println("userObj : " + userObj);

		String command1 = "getUserKeys";
		command1 += "&id=" + userid;
		api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output1 = api.getResultFromRequest(command1, session);

		String secretKey = null;
		try {
			JSONObject obj = new JSONObject(output1);
			obj = obj.getJSONObject("getuserkeysresponse");
			obj = obj.getJSONObject("userkeys");
			secretKey = obj.getString("secretkey");
		} catch (Exception e) {
			// TODO: handle exception
		}

		System.out.println("userObj : " + userObj);
		System.out.println("secretKey : " + secretKey);

		model.addAttribute("userObj", userObj);
		model.addAttribute("secretKey", secretKey);
		return "admin/usersContents";
	}

	@RequestMapping(value = "/admin/vms", method = RequestMethod.GET)
	public String vms(Locale locale, Model model, HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to vms");
		apiDTO apikey = null;
		String command = "listVirtualMachines&listall=true";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// template page 부분에서 id 값 넘어오면, 이거 기반으로 보여줘야 된다.
		String templateid = request.getParameter("templateid");
		if (templateid != null && templateid != "") { // templateid 가 있으면, template 기반으로 값얻기
			command += "&templateid=" + templateid;
		}

		String isoid = request.getParameter("isoid");
		if (isoid != null && isoid != "") { // isoid 가 있으면, iso 기반으로 값얻기
			command += "&isoid=" + isoid;
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		JSONObject obj = new JSONObject(output);

		obj = obj.getJSONObject("listvirtualmachinesresponse");

		// sorting 부분
		JSONArray sortedJsonArray = null;
		if (obj.length() != 0) { // 안지워 졌다면, 0이면 null 반환
			JSONArray arr = (JSONArray) obj.get("virtualmachine");
			sortedJsonArray = new JSONArray();

			List<JSONObject> jsonValues = new ArrayList<JSONObject>();
			for (int i = 0; i < arr.length(); i++) {
				jsonValues.add(arr.getJSONObject(i));
			}
			Collections.sort(jsonValues, new Comparator<JSONObject>() {
				// You can change "Name" with "ID" if you want to sort by ID
				private static final String KEY_NAME = "name"; // key 값, name 으로 정렬함

				public int compare(JSONObject a, JSONObject b) {
					String valA = new String();
					String valB = new String();
					try {
						valA = (String) a.get(KEY_NAME);
						valB = (String) b.get(KEY_NAME);
					} catch (JSONException e) {
						// do something
					}
					// System.out.println("check value : " + valA.compareTo(valB));
					return valA.compareTo(valB);
					// if you want to change the sort order, simply use the following:
					// return -valA.compareTo(valB);
				}
			});
			for (int i = 0; i < arr.length(); i++) {
				sortedJsonArray.put(jsonValues.get(i));
			}
		} else {
			sortedJsonArray = null;
		}
		System.out.println(sortedJsonArray);
		model.addAttribute("vmlist", sortedJsonArray);
		model.addAttribute("templateid", templateid);
		model.addAttribute("isoid", isoid);
		return "admin/vms";
	}

	@RequestMapping(value = "/admin/monitoringContents", method = RequestMethod.POST)
	public String monitoringContents(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to monitoringContents");
		String id = request.getParameter("vmid");
		apiDTO apikey = null;
		String command = "listVirtualMachines&id=" + id;
		// System.out.println("command : " + command);
		String command2 = "";
		String command3 = "";
		JSONObject result = null;
		JSONObject result2 = null;
		JSONObject result3 = null;
		try {
			apikey = api_service.listAPI("OM-admin");
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command, session);
			System.out.println(output);
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listvirtualmachinesresponse");
			// System.out.println(obj);
			JSONArray arr = (JSONArray) obj.get("virtualmachine");
			// System.out.println(arr);
			result = arr.getJSONObject(0);

			command2 = "listTemplates&templatefilter=all&id=" + result.getString("templateid");
			api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api.getResultFromRequest(command2, session);
			System.out.println(output2);
			JSONObject obj2 = new JSONObject(output2);
			obj2 = obj2.getJSONObject("listtemplatesresponse");
			try {
				// template 없는 정신나간게 있네...
				JSONArray arr2 = (JSONArray) obj2.get("template");
				result2 = arr2.getJSONObject(0);
			} catch (Exception e) {
				System.out.println("error : there is no template.");
			}

			command3 = "listVirtualMachines&details=nics&id=" + id;
			api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output3 = api.getResultFromRequest(command3, session);
			System.out.println("result3 : " + output3);
			JSONObject obj3 = new JSONObject(output3);
			obj3 = obj3.getJSONObject("listvirtualmachinesresponse");
			JSONArray arr3 = (JSONArray) obj.get("virtualmachine");
			result3 = arr3.getJSONObject(0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 계정정보 얻기 위해서 billing table 에서 값 가져올것,통합후 추가
		String vmname = result.getString("name");
		BillingDTO billDto = billing_service.selectBillingByVMName(vmname);
		// System.out.println(billDto); // null 이면 jsp 페이지에서 에러 안남, billDto.startday 가
		// null 이라도 마찬가지

		model.addAttribute("billDto", billDto);
		model.addAttribute("vmlist", result);
		model.addAttribute("template", result2);
		model.addAttribute("vmlistnic", result3); // secondary ips 값들 얻어오기 위함

		return "admin/monitoringContents";
	}

	@RequestMapping(value = "/admin/viewSnapshots", method = RequestMethod.POST)
	public String viewSnapshots(Locale locale, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {
		logger.info("viewSnapshots");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String virtualMachineId = request.getParameter("vmid");
		String virtualmachinename = request.getParameter("vmname");
		String command = "listVMSnapshot&listall=true&virtualmachineid=" + virtualMachineId;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println(output);

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listvmsnapshotresponse");
		JSONArray snapshotArr = null;
		// System.out.println(obj.length());
		if (obj.length() != 0) { // snapshot 이 0 이 아닐때만
			snapshotArr = (JSONArray) obj.get("vmSnapshot");
		}
		model.addAttribute("snapshotArr", snapshotArr);
		model.addAttribute("virtualmachineid", virtualMachineId);
		model.addAttribute("virtualmachinename", virtualmachinename);
		return "admin/viewSnapshots";
	}

	@RequestMapping(value = "/admin/snapshotsContents", method = RequestMethod.POST)
	public String snapshotContent(Locale locale, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {
		logger.info("snapshotsContent");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String snapshotid = request.getParameter("snapshotid");
		String vmid = request.getParameter("vmid");
		String vmname = request.getParameter("vmname");
		String command = "listVMSnapshot&listall=true&vmsnapshotid=" + snapshotid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println(output);

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listvmsnapshotresponse");
		JSONArray snapshotArr = (JSONArray) obj.get("vmSnapshot");
		JSONObject snapshotObj = (JSONObject) snapshotArr.get(0);
		model.addAttribute("snapshotObj", snapshotObj);
		model.addAttribute("virtualmachineid", vmid);
		model.addAttribute("virtualmachinename", vmname);
		return "admin/snapshotsContents";
	}

	@RequestMapping(value = "/admin/viewIPs", method = RequestMethod.POST)
	public String viewIPs(Locale locale, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {
		logger.info("viewIPs");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String virtualmachineid = request.getParameter("virtualmachineid");
		String nicid = request.getParameter("nicid");
		String virtualmachinename = request.getParameter("virtualmachinename");
		String zonename = request.getParameter("zonename");

		System.out.println("zonename : " + zonename);
		System.out.println("virtualmachineid : " + virtualmachineid);
		System.out.println("nicid : " + nicid);
		System.out.println("virtualmachinename : " + virtualmachinename);

		String command = "listNics&keyword=&virtualmachineid=" + virtualmachineid + "&nicid=" + nicid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("dddddsdfsdsdf : " + output);

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listnicsresponse");
		// System.out.println("obj1 : " + obj);

		JSONArray nicArr = (JSONArray) obj.get("nic");
		// System.out.println("nicArr : " + nicArr);

		JSONObject obj2 = (JSONObject) nicArr.get(0);
		// System.out.println("obj2 : " + obj2);

		JSONArray secondaryip = null;
		try { // secondaryip가 없으면 그냥 에러 나네..다른 정보들은 있음
			secondaryip = (JSONArray) obj2.get("secondaryip");
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("secondaryip", secondaryip);
		model.addAttribute("virtualmachineid", virtualmachineid);
		model.addAttribute("virtualmachinename", virtualmachinename);
		model.addAttribute("nicid", nicid);
		model.addAttribute("zonename", zonename);

		return "admin/viewIPs";
	}

	@RequestMapping(value = "/admin/IPsContents", method = RequestMethod.POST)
	public String IPsContents(Locale locale, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {
		logger.info("IPsContents");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String nicid = request.getParameter("nicid");
		String vmid = request.getParameter("vmid");
		String vmname = request.getParameter("vmname");
		String ipaddress = request.getParameter("ipaddress");
		String ipid = request.getParameter("ipid");
		String zonename = request.getParameter("zonename");
		String command = "listNics&nicId=" + nicid + "&virtualmachineid=" + vmid + "&keyword=" + ipaddress;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println(output);

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listnicsresponse");
		JSONArray arr = (JSONArray) obj.get("nic");
		obj = (JSONObject) arr.get(0);
		arr = (JSONArray) obj.get("secondaryip");
		JSONObject ipObj = (JSONObject) arr.get(0); // 어차피 하나만 나올거임, 필터링 걸었으니
		// System.out.println(ipObj);
		model.addAttribute("ipObj", ipObj);
		model.addAttribute("virtualmachineid", vmid);
		model.addAttribute("virtualmachinename", vmname);
		model.addAttribute("zonename", zonename);

		System.out.println("zonename : " + zonename + ", vmname : " + vmname);

		return "admin/IPsContents";

	}

	@RequestMapping(value = "/getListSecondaryIPs", method = RequestMethod.POST)
	public void getListSecondaryIPs(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("getListSecondaryIPs");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String nicid = request.getParameter("nicid");
		String vmid = request.getParameter("vmid");
		String ipaddress = request.getParameter("ipaddress");
		String command = "listNics&nicId=" + nicid + "&virtualmachineid=" + vmid + "&keyword=" + ipaddress;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println(output);
		JSONArray result = null;
		try {
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listnicsresponse");
			JSONArray arr = (JSONArray) obj.get("nic");
			JSONObject ipObj = (JSONObject) arr.get(0);
			result = (JSONArray) ipObj.get("secondaryip");
		} catch (Exception e) {
			// TODO: handle exception
		}
		PrintWriter out = response.getWriter();
		out.print(result);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getOutputList", method = RequestMethod.POST)
	public void getOutputList(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws Exception {
		logger.info("getOutputList");
		// 같이 쓰는 함수니깐 함부로 수정하지마시오, 수정할거 생기면 복사해서 새로 만들것

		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);
		System.out.println("outputlist : " + output);
		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getVMByName", method = RequestMethod.POST)
	public void getVMByName(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws Exception {
		logger.info("getVMByName");

		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);
		String instancename = request.getParameter("instancename");

		JSONObject result = null;
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listvirtualmachinesresponse");
		JSONArray arr = (JSONArray) obj.get("virtualmachine");
		for (int i = 0; i < arr.length(); i++) {
			if (instancename.equals(arr.getJSONObject(i).getString("name"))) {
				result = arr.getJSONObject(i);
				break;
			}
		}

		PrintWriter out = response.getWriter();
		out.print(result);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListTemplates", method = RequestMethod.POST)
	public void getListTemplates(Locale locale, Model model, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("getListTemplates");
		apiDTO apikey = null;
		String command = "listTemplates&templatefilter=self";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListHosts", method = RequestMethod.POST)
	public void getListHosts(Locale locale, Model model, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("getListHosts");
		apiDTO apikey = null;
		String command = "listHosts&hypervisor=XenServer";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListMigrateHosts", method = RequestMethod.POST)
	public void getListMigrateHosts(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("getListHosts");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String command = request.getParameter("command");
		String virtualmachineid = request.getParameter("virtualmachineid");

		command += "&virtualmachineid=" + virtualmachineid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		// System.out.println(output);
		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListIsos", method = RequestMethod.POST)
	public void getListIsos(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getListIsos");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api;

		JSONObject returnObj = new JSONObject();

		String[] commands = { "listIsos&isofilter=featured&isready=true", "listIsos&isofilter=community&isready=true",
				"listIsos&isofilter=selfexecutable&isready=true" };

		for (int k = 0; k < commands.length; k++) {
			api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(commands[k], session);

			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listisosresponse");
			JSONArray array = (JSONArray) obj.get("iso");

			for (int i = 0; i < array.length(); i++) {
				returnObj.put((String) array.getJSONObject(i).get("id"),
						(String) array.getJSONObject(i).get("displaytext"));
			}
		}

		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(returnObj);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListSerivce", method = RequestMethod.POST)
	public void getListSerivce(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getListSerivce");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListStoragePools", method = RequestMethod.POST)
	public void getListStoragePools(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("getListStoragePools");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListOsTypes", method = RequestMethod.POST)
	public void getListOsTypes(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getListOsTypes");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListNetwork", method = RequestMethod.POST)
	public void getListNetwork(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getListNetwork");
		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);

		JSONObject returnObj = new JSONObject();

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listnetworksresponse");
		JSONArray array = (JSONArray) obj.get("network");

		for (int i = 0; i < array.length(); i++) {
			returnObj.put((String) array.getJSONObject(i).get("id"), (String) array.getJSONObject(i).get("name"));
		}

		PrintWriter out = response.getWriter();
		out.print(returnObj);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getListIPs", method = RequestMethod.POST)
	public void getListIPs(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getListIPs");
		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);

		JSONObject returnObj = new JSONObject();

		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listpublicipaddressesresponse");
		JSONArray array = (JSONArray) obj.get("publicipaddress");

		for (int i = 0; i < array.length(); i++) {
			returnObj.put((String) array.getJSONObject(i).get("ipaddress"),
					(String) array.getJSONObject(i).get("ipaddress"));
		}

		PrintWriter out = response.getWriter();
		out.print(returnObj);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getDomainsList", method = RequestMethod.POST)
	public void getDomainsList(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getDomainsList");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getAssignAccountsList", method = RequestMethod.POST)
	public void getAssignAccountsList(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("getAssignAccountsList");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getInstanceMetricsList", method = RequestMethod.POST)
	public void getInstanceMetricsList(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("getInstanceMetricsList");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String command = "listVirtualMachinesMetrics&listAll=true";

		// template page 부분에서 id 값 넘어오면, 이거 기반으로 보여줘야 된다.
		String templateid = request.getParameter("templateid");
		System.out.println("templateid : " + templateid);
		if (templateid != null && templateid != "") { // templateid 가 있으면, template 기반으로 값얻기
			command += "&templateid=" + templateid;
		}

		String isoid = request.getParameter("isoid");
		if (isoid != null && isoid != "") { // isoid 가 있으면, isoid 기반으로 값얻기
			command += "&isoid=" + isoid;
		}
		System.out.println("isoid : " + isoid);
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		// System.out.println(output);
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listvirtualmachinesmetricsresponse");
		JSONArray arr = (JSONArray) obj.get("virtualmachine");

		PrintWriter out = response.getWriter();
		out.print(arr);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/getVMVolumeList", method = RequestMethod.POST)
	public void getVMVolumeList(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("getVMVolumeList");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String vmid = request.getParameter("vmid");
		String command = "listVolumes&virtualMachineId=" + vmid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiAttachISO", method = RequestMethod.POST)
	public void apiAttachISO(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAttachISO");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiDetachISO", method = RequestMethod.POST)
	public void apiDetachISO(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDetachISO");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiCreateVMSnapshot", method = RequestMethod.POST)
	public void apiCreateVMSnapshot(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreateVMSnapshot");
		apiDTO apikey = null;

		String command = request.getParameter("command");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		boolean snapshotmemory = Boolean.valueOf(request.getParameter("snapshotmemory"));

		command += "&virtualmachineid=" + id + "&quiesce=false";
		if (name.trim() != "") {
			command += "&name=" + name;
		}
		if (description.trim() != "") {
			command += "&description=" + description;
		}
		if (snapshotmemory) {
			command += "&snapshotmemory=" + snapshotmemory;
		}
		System.out.println("command : " + command);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiChangeServiceOffering", method = RequestMethod.POST)
	public void apiChangeServiceOffering(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiChangeServiceOffering");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiMigratePrimaryStorage", method = RequestMethod.POST)
	public void apiMigratePrimaryStorage(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiMigratePrimaryStorage");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiEditVM", method = RequestMethod.POST)
	public void apiEditVM(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEditVM");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiAssignVirtualMachine", method = RequestMethod.POST)
	public void apiAssignVirtualMachine(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiAssignVirtualMachine");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/apiChangeIPAddress", method = RequestMethod.POST)
	public void apiChangeIPAddress(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiChangeIPAddress");
		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiAcquireNewSecondaryIP", method = RequestMethod.POST)
	public void apiAcquireNewSecondaryIP(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiAcquireNewSecondaryIP");
		apiDTO apikey = null;
		String command = request.getParameter("command");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiReleaseSecondaryIP", method = RequestMethod.POST)
	public void apiReleaseSecondaryIP(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiReleaseSecondaryIP");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String ipid = request.getParameter("ipid");

		String command = "removeIpFromNic&id=" + ipid;

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiCreateAccount", method = RequestMethod.POST)
	public void apiCreateAccount(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiCreateAccount");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String command = request.getParameter("command");
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiDeleteAccountUser", method = RequestMethod.POST)
	public void apiDeleteAccountUser(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeleteAccountUser");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String command = request.getParameter("command");
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiGenerateKey", method = RequestMethod.POST)
	public void apiGenerateKey(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiGenerateKey");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String command = request.getParameter("command");
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiChangePassword", method = RequestMethod.POST)
	public void apiChangePassword(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiChangePassword");
		apiDTO apikey = null;

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String command = request.getParameter("command");
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/license", method = RequestMethod.GET)
	public String license(Locale locale, Model model) throws Exception {
		logger.info("license");

		ArrayList<LicenseDTO> licenseList = license_service.selectLicense();

		model.addAttribute("licenseList", licenseList);

		return "/admin/license";
	}

	@RequestMapping(value = "/admin/addLicense", method = RequestMethod.POST)
	public String addLicense(HttpServletRequest request, LicenseDTO dto) throws Exception {
		logger.info("addLicense");

		System.out.println(dto.toString());

		String modifyNum = request.getParameter("modifyNum");
		System.out.println("modifyNum : " + modifyNum);

		try {
			if (modifyNum == null || modifyNum.trim().equals("")) { // modify number 가 없으면 신규등록
				license_service.insertLicense(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum)); // 수정할 넘버 넣어주기
				license_service.updateLicense(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return "redirect:/admin/license";
	}

	@RequestMapping(value = "/admin/getLicenseData", method = RequestMethod.POST)
	public void getLicenseData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("getLicenseData");

		String modifyNum = request.getParameter("modifyNum");
		System.out.println("modifyNum : " + modifyNum);

		LicenseDTO dto = null;
		try {
			dto = license_service.selectLicenseByNum(modifyNum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dto.toString());

		JSONObject outputObject = new JSONObject();
		outputObject.put("licenseName", dto.getLicenseName());
		outputObject.put("licenseNumber", dto.getLicenseNumber());
		outputObject.put("licenseStatus", dto.getLicenseStatus());
		outputObject.put("licenseGroup", dto.getLicenseGroup());
		outputObject.put("startDay", dto.getStartDay());
		outputObject.put("endDay", dto.getEndDay());
		outputObject.put("count", dto.getCount());

		// ajax로 받는 데이터에서 한글 깨져서, <% %>안에 똑같이 써줬는데 무용지물이었음 이미 로드된 데이터에 삽입하는거라서 그런가봄
		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(outputObject);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/changeLicenseStatus", method = RequestMethod.POST)
	public void changeLicenseStatus(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("changeLicenseStatus");

		String licenseNumbers = request.getParameter("licenseNumbers");
		String licenseStatus = request.getParameter("licenseStatus");

		System.out.println("licenseStatus : " + licenseStatus);
		System.out.println("licenseNumbers : " + licenseNumbers);

		String licenseNumbersSqlString = licenseNumbers.replace(",", "' or num = '");
		licenseNumbersSqlString = "'" + licenseNumbersSqlString + "'";

		System.out.println("licenseNumbersSqlString : " + licenseNumbersSqlString);

		PrintWriter out = response.getWriter();
		String output = license_service.updateMultiLicenseStatus(licenseNumbersSqlString, licenseStatus);
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/setSessionJobid", method = RequestMethod.POST)
	public void setSessionJobid(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("setSessionJobid");
		String jobid = request.getParameter("jobid");
		String work = request.getParameter("work");
		String state = request.getParameter("state").toLowerCase().trim(); // add,del 옵션 두개 있음

		JSONArray jobList = (JSONArray) session.getAttribute("jobList"); // 현재 jobList 얻고
		if (jobList == null) { // 추가 된게 없으면 새로 생성
			jobList = new JSONArray();
		}

		// 이미 완료된것 확인해서 지워줄것
		if (state.equals("add")) {
			JSONObject jobObj = new JSONObject();
			jobObj.put("jobid", jobid);
			jobObj.put("work", work);
			jobList.put(jobObj); // 추가 하고
		} else if (state.equals("del")) { // state del 이니깐 삭제 해줄것
			for (int i = 0; i < jobList.length(); i++) {
				JSONObject obj = (JSONObject) jobList.get(i);

				if (jobid.equals(String.valueOf(obj.get("jobid")))) {
					jobList.remove(i);
					break;
				}
			}
			if (jobList.length() == 0) { // jobList 가 0이 되면 null 로 처리
				jobList = null;
			}
		}

		session.setAttribute("jobList", jobList);
	}

	@RequestMapping(value = "/getSessionJobid", method = RequestMethod.POST)
	public void getSessionJobid(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("getSessionJobid");

		PrintWriter out = response.getWriter();

		JSONArray jobList = (JSONArray) session.getAttribute("jobList");

		out.print(jobList);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/setSessionForNotification", method = RequestMethod.POST)
	public void setSessionInNotification(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("setSessionForNotification");

		String work = request.getParameter("work");
		String count = request.getParameter("count");
		String success = request.getParameter("success");

		JSONArray notificationList = (JSONArray) session.getAttribute("notificationList"); // 현재 notification 얻고
		if (notificationList == null) { // 추가 된게 없으면 새로 생성
			notificationList = new JSONArray();
		}
		JSONObject workObj = new JSONObject();
		workObj.put("work", work);
		workObj.put("id", "notificationid_" + UUID.randomUUID()); // UUID 고유 값으로 삭제할때 사용
		workObj.put("success", success);

		notificationList.put(workObj); // 추가 하고
		session.setAttribute("notificationList", notificationList); // 추가한 JSONArray 넘겨주기
		session.setAttribute("notificationCount", count);

	}

	@RequestMapping(value = "/getSessionForNotification", method = RequestMethod.POST)
	public void getSessionInNotification(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("getSessionForNotification");

		JSONArray notificationList = (JSONArray) session.getAttribute("notificationList");
		String notificationCount = (String) session.getAttribute("notificationCount");

		// 복사할 JSONArray, notificationList가 null 이면 null 로 return 해야 됨
		JSONArray returnNotificationList = null;

		if (notificationList != null) { // session 값이 없으면, 추가된적이 없으면 에러, 새 Array로 보내주는 이유는 work 가 자꾸 추가되므로 count를 추가되는 새
										// array로 만들어서 넘겨준다.
			returnNotificationList = new JSONArray();
			for (int i = 0; i < notificationList.length(); i++) {
				returnNotificationList.put(notificationList.get(i));
			} // clone list

			// list가 값이 있을때 맨마지막 값만 추가
			returnNotificationList.put(returnNotificationList.length(), notificationCount); // 맨 마지막에 notificationCount
																							// 추가
		}

		/*
		 * System.out.println("notificationList : " + notificationList);
		 * System.out.println("returnNotificationList : " + returnNotificationList);
		 */
		PrintWriter out = response.getWriter();

		out.print(returnNotificationList);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/deleteNotificationMethod", method = RequestMethod.POST)
	public void deleteNotificationMethod(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		logger.info("deleteNotificationMethod");

		String selectedId = request.getParameter("id");
		// System.out.println("noti select id : " + selectedId);
		System.out.println("selectedid : " + selectedId);
		JSONArray notificationList = (JSONArray) session.getAttribute("notificationList");
		String notificationCount = (String) session.getAttribute("notificationCount");

		if (selectedId != null) { // id 넘어왔으니 개별 삭제

			// notificationList에서 삭제
			for (int i = 0; i < notificationList.length(); i++) {
				JSONObject obj = (JSONObject) notificationList.get(i);
				if (selectedId.equals(String.valueOf(obj.get("id")))) {
					// 일치하면 찾은것임, 해당 index 삭제
					notificationList.remove(i);
					break;
				}
			}

			// count -1
			int count = Integer.parseInt(notificationCount) - 1;
			session.setAttribute("notificationCount", String.valueOf(count));
			if (count == 0) { // count 가 0 이면 그냥 다 지워줄것
				session.removeAttribute("notificationList");
				session.removeAttribute("notificationCount");
			}

		} else { // id 안넘어왔으니 전체 삭제
			session.removeAttribute("notificationList");
			session.removeAttribute("notificationCount");
		}

	}

	@RequestMapping(value = "/insertInstance", method = RequestMethod.POST)
	public void insertInstanceToDB(HttpServletRequest request, HttpServletResponse response, InstanceDTO dto)
			throws Exception {
		logger.info("insertInstanceToDB");
		dto.setInstancepwd(dto.getInstancename().replaceAll("-", ""));

		System.out.println("pwd : " + dto.getInstancepwd());

		String output = instance_service.insertInstance(dto);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/deleteInstance", method = RequestMethod.POST)
	public void deleteInstanceFromDB(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("deleteInstanceFromDB");

		String instancename = request.getParameter("instancename");

		String output = instance_service.deleteInstance(instancename);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/networks", method = RequestMethod.GET)
	public String networks(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to networks");
		apiDTO apikey = null;
		String command = "listNetworks&listall=true";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listnetworksresponse");
		// obj = obj.getJSONObject("user");
		// System.out.println(obj);
		JSONArray arr = (JSONArray) obj.get("network");
		System.out.println(arr);
		model.addAttribute("networklist", arr);
		return "admin/networks";
	}

	@RequestMapping(value = "/selectAllInstance", method = RequestMethod.POST)
	public void selectAllInstance(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("selectAllInstance");

		ArrayList<InstanceDTO> instanceArrayList = (ArrayList<InstanceDTO>) instance_service.selectAllInstance();
		// json 형태로 변환해서 반환
		JSONArray instanceArr = new JSONArray();
		for (int i = 0; i < instanceArrayList.size(); i++) {
			String id = instanceArrayList.get(i).getInstanceid();
			String name = instanceArrayList.get(i).getInstancename();
			String usage = instanceArrayList.get(i).getInstanceusage();

			JSONObject obj = new JSONObject();
			obj.put("usage", usage);
			obj.put("name", name);
			obj.put("id", id);
			instanceArr.put(obj);
		}

		PrintWriter out = response.getWriter();
		out.print(instanceArr);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/events", method = RequestMethod.GET)
	public String events(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to events");
		apiDTO apikey = null;
		String command = "listEvents&listall=true";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listeventsresponse");
		// obj = obj.getJSONObject("user");
		// System.out.println(obj);
		JSONArray arr = (JSONArray) obj.get("event");
		System.out.println(arr);
		model.addAttribute("eventslist", arr);
		return "admin/events";
	}

	@RequestMapping(value = "/admin/infra", method = RequestMethod.GET)
	public String infra(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to events");
		apiDTO apikey = null;
		String command = "listInfrastructure";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listinfrastructureresponse");
		// obj = obj.getJSONObject("user");
		JSONObject arr = (JSONObject) obj.get("infrastructure");
		System.out.println(arr);
		model.addAttribute("infralist", arr);
		return "admin/infra";
	}

	@RequestMapping(value = "/admin/alert", method = RequestMethod.GET)
	public String alert(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to events");
		apiDTO apikey = null;
		String command = "listAlerts";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listalertsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = (JSONArray) obj.get("alert");
		System.out.println(arr);
		model.addAttribute("alertlist", arr);
		return "admin/alert";
	}

	@RequestMapping(value = "/admin/infra_zone", method = RequestMethod.GET)
	public String infra_zone(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_zone");
		apiDTO apikey = null;
		String command = "listZones";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listzonesresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("zone");
		}
		// System.out.println(arr);
		model.addAttribute("zonelist", arr);
		return "admin/infra_zone";
	}

	@RequestMapping(value = "/admin/infra_pod", method = RequestMethod.GET)
	public String infra_pod(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_pod");
		apiDTO apikey = null;
		String command = "listPods";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listpodsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("pod");
		}
		// System.out.println(arr);
		model.addAttribute("podlist", arr);
		return "admin/infra_pod";
	}

	@RequestMapping(value = "/admin/infra_cluster", method = RequestMethod.GET)
	public String infra_cluster(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_cluster");
		apiDTO apikey = null;
		String command = "listClusters";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listclustersresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("cluster");
		}
		// System.out.println(arr);
		model.addAttribute("clusterlist", arr);
		return "admin/infra_cluster";
	}

	@RequestMapping(value = "/admin/infra_host", method = RequestMethod.GET)
	public String infra_host(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_host");
		apiDTO apikey = null;
		String command = "listHosts&hypervisor=XenServer";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listhostsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("host");
		}
		// System.out.println(arr);
		model.addAttribute("hostlist", arr);
		return "admin/infra_host";
	}

	@RequestMapping(value = "/admin/infra_storage1", method = RequestMethod.GET)
	public String infra_storage1(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_storage1");
		apiDTO apikey = null;
		String command = "listStoragePools";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("liststoragepoolsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("storagepool");
		}
		System.out.println(arr);
		model.addAttribute("storagelist", arr);
		return "admin/infra_storage1";
	}

	@RequestMapping(value = "/admin/infra_storage2", method = RequestMethod.GET)
	public String infra_storage2(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_storage2");
		apiDTO apikey = null;
		String command = "listImageStores";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listimagestoresresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("imagestore");
		}
		// System.out.println(arr);
		model.addAttribute("storagelist", arr);
		return "admin/infra_storage2";
	}

	@RequestMapping(value = "/admin/infra_systemvms", method = RequestMethod.GET)
	public String infra_systemvms(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_systemvms");
		apiDTO apikey = null;
		String command = "listSystemVms";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listsystemvmsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("systemvm");
		}
		System.out.println(arr);
		model.addAttribute("systemvmlist", arr);
		return "admin/infra_systemvms";
	}

	@RequestMapping(value = "/admin/infra_routers", method = RequestMethod.GET)
	public String infra_routers(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to infra_routers");
		apiDTO apikey = null;
		String command = "listRouters&listall=true";
		
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listroutersresponse");
		// obj = obj.getJSONObject("user");
		
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("router");
		}
		
		System.out.println(arr);
	
		model.addAttribute("routerlist", arr);
		return "admin/infra_routers";
	}

	// 민재 + 준승 시작
		@RequestMapping(value = "/admin/infra_zone_details", method = RequestMethod.POST)
		public String infrazonedetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra zone details");

			String parameter = request.getParameter("parameter"); // infra_zone.jsp 에서 넘긴 id 받음

			String id = parameter;

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String listzonecommand = "listZones&id=" + id;
			String listdedicatedzonecommand = "listDedicatedZones&zoneid=" + id;
			// listApis는 dedicate 상태일 때만 response 온다
			String listdomaincommand = "listDomains&listAll=true&details=min";

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listzonecommand, session);
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listzonesresponse");
			JSONArray arr = (JSONArray) obj1.get("zone");

			model.addAttribute("zonelist", arr);

			// dedicate 리스트가 비었으면 그냥 빈 JSON 전송
			try {
				cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output2 = api2.getResultFromRequest(listdedicatedzonecommand, session);
				JSONObject obj2 = new JSONObject(output2);
				obj2 = obj2.getJSONObject("listdedicatedzonesresponse");
				JSONArray arr2 = (JSONArray) obj2.get("zone");

				model.addAttribute("dedizonelist", arr2);

			} catch (Exception e) {
				cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output2 = api2.getResultFromRequest(listdedicatedzonecommand, session);
				JSONObject obj2 = new JSONObject(output2);
				obj2 = obj2.getJSONObject("listdedicatedzonesresponse");

				model.addAttribute("dedizonelist", obj2);
			}

			cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output3 = api3.getResultFromRequest(listdomaincommand, session);
			JSONObject obj3 = new JSONObject(output3);
			obj3 = obj3.getJSONObject("listdomainsresponse");
			JSONArray arr3 = (JSONArray) obj3.get("domain");

			model.addAttribute("domainlist", arr3);

			return "admin/infra_zone_details";
		}
		
		@RequestMapping(value = "/admin/infra_pod_details", method = RequestMethod.POST)
		public String infrapoddetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra pod details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String listpodcommand = "listPods&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listpodcommand, session);
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listpodsresponse");
			JSONArray arr = (JSONArray) obj1.get("pod");

			model.addAttribute("podlist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");

			model.addAttribute("zonelist", arr2);
			
			String listdedicatedpodcommand = "listDedicatedPods&podid=" + id;
			
			// dedicate 리스트가 비었으면 그냥 빈 JSON 전송
					try {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedpodcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedpodsresponse");
						JSONArray arr3 = (JSONArray) obj2.get("pod");

						model.addAttribute("dedipodlist", arr3);

					} catch (Exception e) {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedpodcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedpodsresponse");

						model.addAttribute("dedipodlist", obj3);
					}

					
				String listVlanIpRanges = "listVlanIpRanges&zoneid=" + zoneid + "&podid=" + id;
				
				cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output4 = api4.getResultFromRequest(listVlanIpRanges, session);
				JSONObject obj4 = new JSONObject(output4);
				System.out.println("ssss : " + obj4);
				obj4 = obj4.getJSONObject("listvlaniprangesresponse");
				JSONArray arr4 = (JSONArray) obj4.get("vlaniprange");

				model.addAttribute("vlanlist", arr4);
				
				String listdomaincommand = "listDomains&listAll=true&details=min";
				
				cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output5 = api5.getResultFromRequest(listdomaincommand, session);
				JSONObject obj5 = new JSONObject(output5);
				obj5 = obj5.getJSONObject("listdomainsresponse");
				JSONArray arr5 = (JSONArray) obj5.get("domain");

				model.addAttribute("domainlist", arr5);

			return "admin/infra_pod_details";
		}
		
		@RequestMapping(value = "/admin/infra_cluster_details", method = RequestMethod.POST)  
		public String infraclusterdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra cluster details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String listclustercommand = "listClusters&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listclustercommand, session);
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listclustersresponse");
			JSONArray arr = (JSONArray) obj1.get("cluster");

			model.addAttribute("clusterlist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");

			model.addAttribute("zonelist", arr2);
			
			String listdedicatedpodcommand = "listDedicatedClusters&clusterid=" + id;
			
			// dedicate 리스트가 비었으면 그냥 빈 JSON 전송
					try {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedpodcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedclustersresponse");
						JSONArray arr3 = (JSONArray) obj2.get("cluster");

						model.addAttribute("dediclusterlist", arr3);

					} catch (Exception e) {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedpodcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedclustersresponse");

						model.addAttribute("dediclusterlist", obj3);
					}

				// listConfigurations 라고 api 하나 더 써서 리스폰스 받는데 어디다 쓰는지 모르겠음.
					
				
				String listdomaincommand = "listDomains&listAll=true&details=min";
				
				cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output5 = api5.getResultFromRequest(listdomaincommand, session);
				JSONObject obj5 = new JSONObject(output5);
				obj5 = obj5.getJSONObject("listdomainsresponse");
				JSONArray arr5 = (JSONArray) obj5.get("domain");

				model.addAttribute("domainlist", arr5);

			return "admin/infra_cluster_details";
		}
		
		@RequestMapping(value = "/admin/infra_host_details", method = RequestMethod.POST)  
		public String infrahostdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra host details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String listhostcommand = "listHosts&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listhostcommand, session);
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listhostsresponse");
			JSONArray arr = (JSONArray) obj1.get("host");

			model.addAttribute("hostlist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");

			model.addAttribute("zonelist", arr2);
			
			String listdedicatedhostcommand = "listDedicatedHosts&hostid=" + id;
			
			// dedicate 리스트가 비었으면 그냥 빈 JSON 전송
					try {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedhostcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedhostsresponse");
						JSONArray arr3 = (JSONArray) obj2.get("host");

						model.addAttribute("dedihostlist", arr3);

					} catch (Exception e) {
						cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
						String output3 = api3.getResultFromRequest(listdedicatedhostcommand, session);
						JSONObject obj3 = new JSONObject(output3);
						obj3 = obj3.getJSONObject("listdedicatedhostsresponse");  

						model.addAttribute("dedihostlist", obj3);
					}
	  
				// listConfigurations 라고 api 하나 더 써서 리스폰스 받는데 어디다 쓰는지 모르겠음.
				
				String listoscategoriescommand = "listOsCategories";
				
				cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output4 = api4.getResultFromRequest(listoscategoriescommand, session);
				JSONObject obj4 = new JSONObject(output4);
				obj4 = obj4.getJSONObject("listoscategoriesresponse");
				JSONArray arr4 = (JSONArray) obj4.get("oscategory");

				model.addAttribute("oslist", arr4);
					
				
				String listdomaincommand = "listDomains&listAll=true&details=min";
				
				cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output5 = api5.getResultFromRequest(listdomaincommand, session);
				JSONObject obj5 = new JSONObject(output5);
				obj5 = obj5.getJSONObject("listdomainsresponse");
				JSONArray arr5 = (JSONArray) obj5.get("domain");

				model.addAttribute("domainlist", arr5);

			return "admin/infra_host_details";  
		}  
		
		@RequestMapping(value = "/admin/infra_storage1_details", method = RequestMethod.POST)  
		public String infrastorage1details(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra storage1 details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String liststorage1command = "listStoragePools&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(liststorage1command, session);
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("liststoragepoolsresponse");
			JSONArray arr = (JSONArray) obj1.get("storagepool");

			model.addAttribute("storagelist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");

			model.addAttribute("zonelist", arr2);
			
			String storageID = arr.getJSONObject(0).getString("id");
			
			String listconfigurationcommand = "listConfigurations&storageid=" + storageID + "&listAll=true&page=1&pagesize=20";
				
				cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output3 = api3.getResultFromRequest(listconfigurationcommand, session);
				JSONObject obj3 = new JSONObject(output3);
				obj3 = obj3.getJSONObject("listconfigurationsresponse");
				JSONArray arr3 = (JSONArray) obj3.get("configuration");

				model.addAttribute("configurationlist", arr3);

			return "admin/infra_storage1_details";
		}

		@RequestMapping(value = "/admin/infra_storage2_details", method = RequestMethod.POST)  
		public String infrastorage2details(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra routers details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String liststorage2command = "listImageStores&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(liststorage2command, session);  
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listimagestoresresponse");
			JSONArray arr = (JSONArray) obj1.get("imagestore");

			model.addAttribute("storagelist", arr);
			
			return "admin/infra_storage2_details";
		}
		
		@RequestMapping(value = "/admin/infra_systemvms_details", method = RequestMethod.POST)  
		public String infrasystemvmsdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra storage2 details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
  
			String listsystemvmscommand = "listSystemVms&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listsystemvmscommand, session);  
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listsystemvmsresponse");
			JSONArray arr = (JSONArray) obj1.get("systemvm");

			model.addAttribute("systemvmslist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");
			
			model.addAttribute("zonelist", arr2);
			
			return "admin/infra_systemvms_details";
		}
		
		@RequestMapping(value = "/admin/infra_routers_details", method = RequestMethod.POST)  
		public String infraroutersdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra routers details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
  
			String listroutercommand = "listRouters&id=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listroutercommand, session);  
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listroutersresponse");
			JSONArray arr = (JSONArray) obj1.get("router");  

			model.addAttribute("routerlist", arr);
			
			String zoneid = arr.getJSONObject(0).getString("zoneid");
			
			String listzonecommand = "listZones&id=" + zoneid;
			
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(listzonecommand, session);
			JSONObject obj2 = new JSONObject(output2);
			System.out.println("ssss : " + obj2);
			obj2 = obj2.getJSONObject("listzonesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("zone");
			
			model.addAttribute("zonelist", arr2);

			
			return "admin/infra_routers_details";
		}
		
		@RequestMapping(value = "/admin/infra_socket", method = RequestMethod.GET)  
		public String infrasocketdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra sockets details");
			System.out.println("sockets");

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String listxenservercommand = "listHosts&type=routing&hypervisor=XenServer";

			
			// response 비었으면 빈 JSON전송 (오류를 막기 위함)
			
			
			try {
				cloudstack_api api7 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output7 = api7.getResultFromRequest(listxenservercommand, session);
				JSONObject obj7 = new JSONObject(output7);
				obj7 = obj7.getJSONObject("listhostsresponse");
				JSONArray arr7 = (JSONArray) obj7.get("host");

				model.addAttribute("xenserverlist", arr7);

			} catch (Exception e) {
				cloudstack_api api7 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output7 = api7.getResultFromRequest(listxenservercommand, session);
				JSONObject obj7 = new JSONObject(output7);
				obj7 = obj7.getJSONObject("listhostsresponse");

				model.addAttribute("xenserverlist", obj7);
			}
			
			return "admin/infra_socket";
		}
		
		@RequestMapping(value = "/admin/infra_physicalnetwork", method = RequestMethod.POST)  
		public String infraphysicalnetwork(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra physical network details");

			String parameter = request.getParameter("parameter"); // infra_pod.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			System.out.println("아이디 = " + id);

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
  
			String listphysicalnetworkcommand = "listTrafficTypes&physicalnetworkid=" + id;

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(listphysicalnetworkcommand, session);  
			JSONObject obj1 = new JSONObject(output1);
			System.out.println("ssss : " + obj1);
			obj1 = obj1.getJSONObject("listtraffictypesresponse");
			JSONArray arr = (JSONArray) obj1.get("traffictype");  

			model.addAttribute("physicalnetworklist", arr);
	
			return "admin/infra_physicalnetwork";
		}
		
		@RequestMapping(value = "/admin/infra_physicalnetwork_details", method = RequestMethod.POST)  
		public String infraphysicalnetworkdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {
			logger.info("go to infra physical network details");

			String parameter = request.getParameter("parameter"); // infra_physicalnetwork.jsp 에서 넘긴 trrafictype 받음
			String parameter2 = request.getParameter("parameter2"); // infra_physicalnetwork.jsp 에서 넘긴 id 받음

			String trafficType = parameter;
			String id = parameter2;

			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				System.out.println("traffictype이랑 id = " + trafficType + id);
			
				String listphysicalnetworkcommand = "listPhysicalNetworks&id=" + id;
	
				cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output1 = api.getResultFromRequest(listphysicalnetworkcommand, session);  
				JSONObject obj1 = new JSONObject(output1);
				System.out.println("ssss : " + obj1);
				obj1 = obj1.getJSONObject("listphysicalnetworksresponse");
				JSONArray arr = (JSONArray) obj1.get("physicalnetwork");  
				
				String zoneId = arr.getJSONObject(0).getString("zoneid");
		
			if (trafficType.equals("Guest"))
			{
				model.addAttribute("physicalnetworklist", arr);
				model.addAttribute("networklist", "Guest");
			}

		
			else
			{
				String listnetworkcommand = "listNetworks&listAll=true&issystem=true&trafficType=" + trafficType + "&zoneId=" + zoneId;
				cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output2 = api2.getResultFromRequest(listnetworkcommand, session);  
				JSONObject obj2 = new JSONObject(output2);
				System.out.println("ssss : " + obj2);
				obj2 = obj2.getJSONObject("listnetworksresponse");
				JSONArray arr2 = (JSONArray) obj2.get("network");
				arr2.put("Non-Guest");
				
				model.addAttribute("physicalnetworklist", trafficType);   
				model.addAttribute("networklist", arr2);
			}
			
			String listtrafficcommand = "listTrafficTypes&physicalnetworkid=" + id;
			cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output3 = api3.getResultFromRequest(listtrafficcommand, session);  
			JSONObject obj3 = new JSONObject(output3);
			System.out.println("ssss : " + obj3);
			obj3 = obj3.getJSONObject("listtraffictypesresponse");
			JSONArray arr3 = (JSONArray) obj3.get("traffictype");
			
			model.addAttribute("trafficlist", arr3);
			

	
			return "admin/infra_physicalnetwork_details";
			
			
		}
		
		@RequestMapping(value = "/admin/infra_networkserviceprovider", method = RequestMethod.POST)  
		public String infranetworkserviceprovider(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
				HttpSession session) throws Exception {

			
			String parameter = request.getParameter("parameter"); // infra_physicalnetwork.jsp 에서 넘긴 id 받음

			String id = parameter;
			
			apiDTO apikey = null;
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				String listprovidercommand = "listNetworkServiceProviders&physicalnetworkid=" + id;
				cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
				String output4 = api4.getResultFromRequest(listprovidercommand, session);  
				JSONObject obj4 = new JSONObject(output4);
				System.out.println("ssss : " + obj4);
				obj4 = obj4.getJSONObject("listnetworkserviceprovidersresponse");
				JSONArray arr4 = (JSONArray) obj4.get("networkserviceprovider");
			
				model.addAttribute("providerlist", arr4);
				
				return "admin/infra_networkserviceprovider";

			
		}
		
		@RequestMapping(value = "/apiInfraDetails", method = RequestMethod.POST)
		public void apiInfraDetails(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
				HttpSession session) throws Exception {
			logger.info("apiInfraDetails");
			apiDTO apikey = null;
			String command = request.getParameter("test");

			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command, session);
			System.out.println("output = " + output);

			PrintWriter out = response.getWriter();
			out.print(output);
			out.flush();
			out.close();
		}

		// 민재 + 준승 끝

	// 김준승 추가 start
	@RequestMapping(value = "/admin/templates", method = RequestMethod.GET)
	public String templates(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to templates");
		apiDTO apikey = null;
		String command1 = "listTemplates&listAll=true&templatefilter=all";

		String commandzone = "listZones&available=true";
		String commandconfiguration = "listConfigurations&name=xenserver.pvdriver.version";
		String commandostype = "listOsTypes";
		String commandhyper = "listHypervisors";

		String commandiso = "listIsos&listAll=true&isofilter=all";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command1, session);
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listtemplatesresponse");
		JSONArray arr = (JSONArray) obj.get("template");
		System.out.println(arr);
		model.addAttribute("templatelist", arr);

		cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputzone = api2.getResultFromRequest(commandzone, session);
		JSONObject objzone = new JSONObject(outputzone);
		objzone = objzone.getJSONObject("listzonesresponse");
		JSONArray arrzone = (JSONArray) objzone.get("zone");
		System.out.println(arrzone);
		model.addAttribute("zonelist", arrzone);

		cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputconfiguration = api3.getResultFromRequest(commandconfiguration, session);
		JSONObject objconfiguration = new JSONObject(outputconfiguration);
		objconfiguration = objconfiguration.getJSONObject("listconfigurationsresponse");
		JSONArray arrconfiguration = (JSONArray) objconfiguration.get("configuration");
		System.out.println(arrconfiguration);
		model.addAttribute("configurationlist", arrconfiguration);

		cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputostype = api4.getResultFromRequest(commandostype, session);
		JSONObject objostype = new JSONObject(outputostype);
		objostype = objostype.getJSONObject("listostypesresponse");
		JSONArray arrostype = (JSONArray) objostype.get("ostype");
		System.out.println(arrostype);
		model.addAttribute("ostypelist", arrostype);

		cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputiso = api5.getResultFromRequest(commandiso, session);
		JSONObject objiso = new JSONObject(outputiso);
		objiso = objiso.getJSONObject("listisosresponse");
		JSONArray arriso = (JSONArray) objiso.get("iso");
		System.out.println(arriso);
		model.addAttribute("isolist", arriso);

		cloudstack_api api6 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputhyper = api6.getResultFromRequest(commandhyper, session);
		JSONObject objhyper = new JSONObject(outputhyper);
		objhyper = objhyper.getJSONObject("listhypervisorsresponse");
		JSONArray arrhyper = (JSONArray) objhyper.get("hypervisor");
		System.out.println(arrhyper);
		model.addAttribute("hyperlist", arrhyper);

		return "admin/templates";
	}

	@RequestMapping(value = "/admin/templatesdetails", method = RequestMethod.POST)
	public String templatesdetails(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws Exception {
		logger.info("go to templates details");

		String parameter = request.getParameter("parameter");
		String[] array = parameter.split("/");
		String id = array[0];
		String kind = array[1];
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (kind.equals("template")) {
			String commandtemplatelist = "listTemplates&templatefilter=self&id=" + id;
			String commandostypelist = "listOsTypes";

			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(commandtemplatelist, session);
			JSONObject obj1 = new JSONObject(output1);
			obj1 = obj1.getJSONObject("listtemplatesresponse");
			JSONArray arr = (JSONArray) obj1.get("template");

			try {
				JSONObject o = arr.getJSONObject(0).getJSONObject("details");
				model.addAttribute("settinglist", o);
			} catch (Exception e) {
				// TODO: handle exception
			}

			model.addAttribute("templatelist", arr);
			model.addAttribute("templatekind", kind);

			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(commandostypelist, session);
			JSONObject obj2 = new JSONObject(output2);
			obj2 = obj2.getJSONObject("listostypesresponse");
			JSONArray arr2 = (JSONArray) obj2.get("ostype");
			model.addAttribute("ostypelist", arr2);

		} else if (kind.equals("iso")) {
			String commandosilist = "listIsos&isofilter=self&id=" + id;
			String commandostypelist = "listOsTypes";
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(commandosilist, session);
			JSONObject obj2 = new JSONObject(output2);
			obj2 = obj2.getJSONObject("listisosresponse");
			JSONArray arr2 = (JSONArray) obj2.get("iso");
			model.addAttribute("isolist", arr2);
			model.addAttribute("templatekind", kind);

			cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output3 = api3.getResultFromRequest(commandostypelist, session);
			JSONObject obj3 = new JSONObject(output3);
			obj3 = obj3.getJSONObject("listostypesresponse");
			JSONArray arr3 = (JSONArray) obj3.get("ostype");
			model.addAttribute("ostypelist", arr3);
		}
		return "admin/templatesdetails";
	}

	@RequestMapping(value = "/apitemplate", method = RequestMethod.POST)
	public void apitemplate(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiTemplate");
		apiDTO apikey = null;
		String command = request.getParameter("test");

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output = " + output);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/serviceoffering", method = RequestMethod.GET)
	public String serviceoffering(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to service offering");
		apiDTO apikey = null;
		String commandcomputeoffering = "listServiceOfferings&listall=true";
		String commanddeployment = "listDeploymentPlanners";

		String commanddomain = "listDomains&listAll=true";

		String commandsystemoffering = "listServiceOfferings&listall=true&issystem=true";

		String commanddiskoffering = "listDiskOfferings&listall=true";

		String commandnetworkoffering = "listNetworkOfferings&listAll=true&page=1&pagesize=20";
		String commandsupported = "listSupportedNetworkServices";
		String commandnetworkserviceoffering = "listServiceOfferings&issystem=true&systemvmtype=domainrouter";
		String commandzone = "listZones";

		String commandvpcoffering = "listVPCOfferings&listAll=true&page=1&pagesize=20";
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output1 = api.getResultFromRequest(commandcomputeoffering, session);
		JSONObject obj1 = new JSONObject(output1);
		obj1 = obj1.getJSONObject("listserviceofferingsresponse");
		JSONArray arr = (JSONArray) obj1.get("serviceoffering");
		model.addAttribute("serviceofferinglist", arr);

		cloudstack_api apideployment = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
				apikey.getBaseURL());
		String outputdeployment = apideployment.getResultFromRequest(commanddeployment, session);
		JSONObject objdeployment = new JSONObject(outputdeployment);
		objdeployment = objdeployment.getJSONObject("listdeploymentplannersresponse");
		JSONArray arrdeployment = (JSONArray) objdeployment.get("deploymentPlanner");
		model.addAttribute("deploymentlist", arrdeployment);

		cloudstack_api apidomain = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputdomain = apidomain.getResultFromRequest(commanddomain, session);
		JSONObject objdomain = new JSONObject(outputdomain);
		objdomain = objdomain.getJSONObject("listdomainsresponse");
		JSONArray arrdomain = (JSONArray) objdomain.get("domain");
		model.addAttribute("domainlist", arrdomain);

		cloudstack_api apisupported = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
				apikey.getBaseURL());
		String outputsupported = apisupported.getResultFromRequest(commandsupported, session);
		JSONObject objsupported = new JSONObject(outputsupported);
		objsupported = objsupported.getJSONObject("listsupportednetworkservicesresponse");
		JSONArray arrsupported = (JSONArray) objsupported.get("networkservice");
		model.addAttribute("supportedlist", arrsupported);

		cloudstack_api apiso = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputso = apiso.getResultFromRequest(commandnetworkserviceoffering, session);
		JSONObject objso = new JSONObject(outputso);
		objso = objso.getJSONObject("listserviceofferingsresponse");
		JSONArray arrso = (JSONArray) objso.get("serviceoffering");
		model.addAttribute("solist", arrso);

		cloudstack_api apizone = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputzone = apizone.getResultFromRequest(commandzone, session);
		JSONObject objzone = new JSONObject(outputzone);
		objzone = objzone.getJSONObject("listzonesresponse");
		JSONArray arrzone = (JSONArray) objzone.get("zone");
		model.addAttribute("zonelist", arrzone);

		cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output2 = api2.getResultFromRequest(commandsystemoffering, session);
		JSONObject obj2 = new JSONObject(output2);
		obj2 = obj2.getJSONObject("listserviceofferingsresponse");
		JSONArray arr2 = (JSONArray) obj2.get("serviceoffering");
		model.addAttribute("systemofferinglist", arr2);
		System.out.println(arr2);

		cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output3 = api3.getResultFromRequest(commanddiskoffering, session);
		System.out.println("output3 = " + output3);
		JSONObject obj3 = new JSONObject(output3);
		System.out.println("obj3 = " + obj3);

		obj3 = obj3.getJSONObject("listdiskofferingsresponse");

		System.out.println("obj3 = " + obj3);
		JSONArray arr3 = (JSONArray) obj3.get("diskoffering");
		System.out.println("arr3 = " + arr3);
		model.addAttribute("diskofferinglist", arr3);
		System.out.println(arr3);

		cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output4 = api4.getResultFromRequest(commandnetworkoffering, session);
		JSONObject obj4 = new JSONObject(output4);
		obj4 = obj4.getJSONObject("listnetworkofferingsresponse");
		JSONArray arr4 = (JSONArray) obj4.get("networkoffering");
		model.addAttribute("networkofferinglist", arr4);
		System.out.println(arr4);

		cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output5 = api5.getResultFromRequest(commandvpcoffering, session);
		JSONObject obj5 = new JSONObject(output5);
		obj5 = obj5.getJSONObject("listvpcofferingsresponse");
		JSONArray arr5 = (JSONArray) obj5.get("vpcoffering");
		model.addAttribute("vpcofferinglist", arr5);
		System.out.println(arr5);

		return "admin/serviceoffering";
	}

	@RequestMapping(value = "/admin/serviceofferingdetails", method = RequestMethod.POST)
	public String serviceofferingdetails(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to service offering details");

		String parameter = request.getParameter("parameter");
		String[] array = parameter.split("/");
		String id = array[0];
		String kind = array[1];
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 시스템 오퍼링 descripton들이 다 비어있어서 오류나는데 그것을 잡아주기 위함(원래 description은 필수값임)
		String specialsystemoffering = "listServiceOfferings&issystem=true";
		cloudstack_api apis = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String outputs = apis.getResultFromRequest(specialsystemoffering, session);
		JSONObject objs = new JSONObject(outputs);
		objs = objs.getJSONObject("listserviceofferingsresponse");
		JSONArray arrs = (JSONArray) objs.get("serviceoffering");
		model.addAttribute("specialsystemofferinglist", arrs);

		if (kind.equals("cpt")) {
			String commandcomputeoffering = "listServiceOfferings&id=" + id;
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output1 = api.getResultFromRequest(commandcomputeoffering, session);
			JSONObject obj1 = new JSONObject(output1);
			obj1 = obj1.getJSONObject("listserviceofferingsresponse");
			JSONArray arr = (JSONArray) obj1.get("serviceoffering");
			model.addAttribute("serviceofferinglist", arr);
			model.addAttribute("serviceofferingkind", kind);
		} else if (kind.equals("sys")) {
			String commandsystemoffering = "listServiceOfferings&issystem=true&id=" + id;
			cloudstack_api api2 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output2 = api2.getResultFromRequest(commandsystemoffering, session);
			JSONObject obj2 = new JSONObject(output2);
			obj2 = obj2.getJSONObject("listserviceofferingsresponse");
			JSONArray arr2 = (JSONArray) obj2.get("serviceoffering");
			model.addAttribute("systemofferinglist", arr2);
			model.addAttribute("serviceofferingkind", kind);
		} else if (kind.equals("disk")) {
			String commanddiskoffering = "listDiskOfferings&id=" + id;
			cloudstack_api api3 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output3 = api3.getResultFromRequest(commanddiskoffering, session);
			JSONObject obj3 = new JSONObject(output3);
			obj3 = obj3.getJSONObject("listdiskofferingsresponse");
			JSONArray arr3 = (JSONArray) obj3.get("diskoffering");
			model.addAttribute("diskofferinglist", arr3);
			model.addAttribute("serviceofferingkind", kind);
		} else if (kind.equals("net")) {
			String commandnetworkoffering = "listNetworkOfferings&id=" + id;
			cloudstack_api api4 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output4 = api4.getResultFromRequest(commandnetworkoffering, session);
			JSONObject obj4 = new JSONObject(output4);
			obj4 = obj4.getJSONObject("listnetworkofferingsresponse");
			JSONArray arr4 = (JSONArray) obj4.get("networkoffering");
			JSONObject tmpobj = arr4.getJSONObject(0);
			JSONArray tmpArr = tmpobj.getJSONArray("service");

			model.addAttribute("networkofferinglist", arr4);
			model.addAttribute("serviceofferingkind", kind);
			model.addAttribute("networkofferingservice", tmpArr);
		} else if (kind.equals("vpc")) {
			String commandvpcoffering = "listVPCOfferings&id=" + id;
			cloudstack_api api5 = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output5 = api5.getResultFromRequest(commandvpcoffering, session);
			JSONObject obj5 = new JSONObject(output5);
			obj5 = obj5.getJSONObject("listvpcofferingsresponse");
			JSONArray arr5 = (JSONArray) obj5.get("vpcoffering");
			JSONObject tmpobj = arr5.getJSONObject(0);
			JSONArray tmpArr = tmpobj.getJSONArray("service");

			model.addAttribute("vpcofferinglist", arr5);
			model.addAttribute("serviceofferingkind", kind);
			model.addAttribute("vpcofferingservice", tmpArr);
		}

		return "admin/serviceofferingdetails";
	}

	@RequestMapping(value = "/apiEditServiceOffering", method = RequestMethod.POST)
	public void apiEditServiceOffering(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiEditServiceOffering");
		apiDTO apikey = null;
		String command = request.getParameter("test");

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output = " + output);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiNetworkOffering", method = RequestMethod.POST)
	public void apiNetworkOffering(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiNetworkOffering");
		apiDTO apikey = null;
		String command1 = request.getParameter("name");
		String command2 = request.getParameter("displayText");
		String command3 = request.getParameter("networkRate");
		String command4 = request.getParameter("guestIpType");

		String command5 = request.getParameter("isPersistent");
		String command6 = request.getParameter("specifyVlan");
		String command7 = request.getParameter("forvpc");

		String command8 = request.getParameter("serviceofferingid");

		String[] cap = new String[10];

		cap[0] = request.getParameter("servicecapabilitylist[0].service");
		cap[1] = request.getParameter("servicecapabilitylist[0].capabilitytype");
		cap[2] = request.getParameter("servicecapabilitylist[0].capabilityvalue");
		cap[3] = request.getParameter("servicecapabilitylist[1].service");
		cap[4] = request.getParameter("servicecapabilitylist[1].capabilitytype");
		cap[5] = request.getParameter("servicecapabilitylist[1].capabilityvalue");

		String command15 = request.getParameter("tags");
		String command16 = request.getParameter("supportedServices");
		String command17 = request.getParameter("conservemode");

		String[] spt = new String[100];
		String[] spt2 = new String[100];

		spt[0] = request.getParameter("serviceProviderList[0].service");
		spt2[0] = request.getParameter("serviceProviderList[0].provider");
		spt[1] = request.getParameter("serviceProviderList[1].service");
		spt2[1] = request.getParameter("serviceProviderList[1].provider");
		spt[2] = request.getParameter("serviceProviderList[2].service");
		spt2[2] = request.getParameter("serviceProviderList[2].provider");
		spt[3] = request.getParameter("serviceProviderList[3].service");
		spt2[3] = request.getParameter("serviceProviderList[3].provider");
		spt[4] = request.getParameter("serviceProviderList[4].service");
		spt2[4] = request.getParameter("serviceProviderList[4].provider");
		spt[5] = request.getParameter("serviceProviderList[5].service");
		spt2[5] = request.getParameter("serviceProviderList[5].provider");
		spt[6] = request.getParameter("serviceProviderList[6].service");
		spt2[6] = request.getParameter("serviceProviderList[6].provider");
		spt[7] = request.getParameter("serviceProviderList[7].service");
		spt2[7] = request.getParameter("serviceProviderList[7].provider");
		spt[8] = request.getParameter("serviceProviderList[8].service");
		spt2[8] = request.getParameter("serviceProviderList[8].provider");
		spt[9] = request.getParameter("serviceProviderList[9].service");
		spt2[9] = request.getParameter("serviceProviderList[9].provider");
		spt[10] = request.getParameter("serviceProviderList[10].service");
		spt2[10] = request.getParameter("serviceProviderList[10].provider");
		spt[11] = request.getParameter("serviceProviderList[11].service");
		spt2[11] = request.getParameter("serviceProviderList[11].provider");
		spt[12] = request.getParameter("serviceProviderList[12].service");
		spt2[12] = request.getParameter("serviceProviderList[12].provider");

		String[] detail = new String[10];

		detail[0] = request.getParameter("details[0].promiscuousMode");
		detail[1] = request.getParameter("details[0].macAddressChanges");
		detail[2] = request.getParameter("details[0].forgedTransmits");

		String command47 = request.getParameter("traffictype");

		String command = "";

		command = "createNetworkOffering&name=" + command1 + "&displaytext=" + command2;

		if (command3 != "")
			command += "&networkrate=" + command3;

		command += "&guestiptype=" + command4;

		if (command4 == "shared")
			command += "&specifyIpRanges=true";

		if (!command5.equals("false"))
			command += "&ispersistent=" + command5;

		if (!command6.equals("false"))
			command += "&specifyvlan=" + command6;

		if (!command7.equals("false"))
			command += "&forvpc=" + command7;

		if (command8 != "")
			command += "&serviceofferingid=" + command8;

		for (int i = 0; i < 2; i++) {
			if (cap[3 * i] == "")
				break;
			else {
				command += "&servicecapabilitylist[" + i + "].service=" + cap[i] + "&servicecapabilitylist[" + i
						+ "].capabilitytype=" + cap[i + 1] + "&servicecapabilitylist[" + i + "].capabilityvalue="
						+ cap[i + 2];
			}

		}

		if (command15 != "")
			command += "&tags=" + command15;

		command += "&supportedservices=" + command16;

		if (!command17.equals("false"))
			command += "&conservemode=" + command17;

		for (int i = 0; i < 13; i++) {
			if (spt[i] == "")
				break;
			else
				command += "&serviceProviderList[" + i + "].service=" + spt[i] + "&serviceProviderList[" + i
						+ "].provider=" + spt2[i];
		}

		for (int i = 0; i < 1; i++) {
			if (detail[i] == "")
				break;
			else {
				command += "&details[0].promiscuousmode=" + detail[0] + "&details[0].macaddresschanges=" + detail[1]
						+ "&details[0].forgedtransmits=" + detail[2];
			}
		}

		command += "&traffictype=" + command47;

		System.out.println("Ŀ�ǵ�" + command);

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output = " + output);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiVPCOffering", method = RequestMethod.POST)
	public void apiVPCOffering(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiVPCOffering");
		apiDTO apikey = null;
		String command1 = request.getParameter("name");
		String command2 = request.getParameter("displayText");

		String[] cap = new String[100];

		cap[0] = request.getParameter("servicecapabilitylist[0].service");
		cap[1] = request.getParameter("servicecapabilitylist[0].capabilitytype");
		cap[2] = request.getParameter("servicecapabilitylist[0].capabilityvalue");
		cap[3] = request.getParameter("servicecapabilitylist[1].service");
		cap[4] = request.getParameter("servicecapabilitylist[1].capabilitytype");
		cap[5] = request.getParameter("servicecapabilitylist[1].capabilityvalue");
		cap[6] = request.getParameter("servicecapabilitylist[2].service");
		cap[7] = request.getParameter("servicecapabilitylist[2].capabilitytype");
		cap[8] = request.getParameter("servicecapabilitylist[2].capabilityvalue");

		String command3 = request.getParameter("state");
		String command4 = request.getParameter("status");
		String command5 = request.getParameter("allocationstate");
		String command6 = request.getParameter("supportedServices");

		String[] spt = new String[100];
		String[] spt2 = new String[100];

		spt[0] = request.getParameter("serviceProviderList[0].service");
		spt2[0] = request.getParameter("serviceProviderList[0].provider");
		spt[1] = request.getParameter("serviceProviderList[1].service");
		spt2[1] = request.getParameter("serviceProviderList[1].provider");
		spt[2] = request.getParameter("serviceProviderList[2].service");
		spt2[2] = request.getParameter("serviceProviderList[2].provider");
		spt[3] = request.getParameter("serviceProviderList[3].service");
		spt2[3] = request.getParameter("serviceProviderList[3].provider");
		spt[4] = request.getParameter("serviceProviderList[4].service");
		spt2[4] = request.getParameter("serviceProviderList[4].provider");
		spt[5] = request.getParameter("serviceProviderList[5].service");
		spt2[5] = request.getParameter("serviceProviderList[5].provider");
		spt[6] = request.getParameter("serviceProviderList[6].service");
		spt2[6] = request.getParameter("serviceProviderList[6].provider");
		spt[7] = request.getParameter("serviceProviderList[7].service");
		spt2[7] = request.getParameter("serviceProviderList[7].provider");
		spt[8] = request.getParameter("serviceProviderList[8].service");
		spt2[8] = request.getParameter("serviceProviderList[8].provider");
		spt[9] = request.getParameter("serviceProviderList[9].service");
		spt2[9] = request.getParameter("serviceProviderList[9].provider");
		spt[10] = request.getParameter("serviceProviderList[10].service");
		spt2[10] = request.getParameter("serviceProviderList[10].provider");

		String command = "";

		command = "createVPCOffering&name=" + command1 + "&displaytext=" + command2;

		for (int i = 0; i < 3; i++) {
			if (cap[3 * i] == "")
				break;
			else {
				command += "&servicecapabilitylist[" + i + "].service=" + cap[i] + "&servicecapabilitylist[" + i
						+ "].capabilitytype=" + cap[i + 1] + "&servicecapabilitylist[" + i + "].capabilityvalue="
						+ cap[i + 2];
			}

		}

		command += "&state=" + command3 + "&status=" + command4 + "&allocationstate=" + command5 + "&supportedservices="
				+ command6;

		for (int i = 0; i < 11; i++) {
			if (spt[i] == "")
				break;
			else
				command += "&serviceProviderList[" + i + "].service=" + spt[i] + "&serviceProviderList[" + i
						+ "].provider=" + spt2[i];
		}

		System.out.println("커맨드" + command);

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		System.out.println("output = " + output);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	// 김준승 추가 end

	//////////////////////////
	// 영기 추가 Start
	//////////////////////////

	// 영기 버튼 API 추가 시작
	@RequestMapping(value = "/apilistZones", method = RequestMethod.POST)
	public void listZones(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_ZoneList");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String str = "listZones";
		String output = api.getResultFromRequest(str, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apilistDiskOfferings", method = RequestMethod.POST)
	public void apilistDiskOfferings(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws IOException {
		logger.info("api_listDiskOfferings");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String str = "listDiskOfferings";
		String output = api.getResultFromRequest(str, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apicreateVolume", method = RequestMethod.POST)
	public void apicreateVolume(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_createVolume");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		System.out.println("output : " + output);
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apiCall", method = RequestMethod.POST)
	public void apiCall(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_resizeVolume");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		System.out.println("output : " + output);
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apicreateSnapshot", method = RequestMethod.POST)
	public void apicreateSnapshot(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_createSnapshot");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);

		PrintWriter out = response.getWriter();
		System.out.println("output : " + output);
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/apilistVirtualMachines", method = RequestMethod.POST)
	public void apilistVirtualMachines(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws IOException {
		logger.info("api_listVirtualMachines");
		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		PrintWriter out = response.getWriter();
		String str = "listVirtualMachines";
		String output = api.getResultFromRequest(str, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	// 영기 추가 Storage
	@RequestMapping(value = "/admin/storage", method = RequestMethod.GET)
	public String storage(Locale locale, Model model, HttpSession session) throws Exception {
		logger.info("go to storage");
		apiDTO apikey = null;
		String command1 = "listVolumes&listall=true";
		String command2 = "listVMSnapshot&listall=true";
		String command3 = "listVolumesMetrics&listall=true";
		String command4 = "listSnapshots&listall=true";
		String command5 = "listEvents&listall=true";

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// volume부분
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output1 = api.getResultFromRequest(command1, session);
		JSONObject object_listvolume = new JSONObject(output1);
		object_listvolume = object_listvolume.getJSONObject("listvolumesresponse");
		if (!object_listvolume.isNull("volume")) {
			JSONArray listvolumes = (JSONArray) object_listvolume.get("volume");
			System.out.println("volume 부분 : " + listvolumes);
			model.addAttribute("storagelist", listvolumes);
		}

		// vmsnapshot부분
		api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output2 = api.getResultFromRequest(command2, session);
		System.out.println(output2);
		JSONObject object_vmsnapshot = new JSONObject(output2);
		// 오류발생 A JSONObject text must begin with '{' at 1 [character 2 line 1]] with
		// root cause
		// api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
		// apikey.getBaseURL());를 새로 선언해 주어야 된다.
		object_vmsnapshot = object_vmsnapshot.getJSONObject("listvmsnapshotresponse");
		if (!object_vmsnapshot.isNull("vmSnapshot")) {
			JSONArray listvmsnapshot = (JSONArray) object_vmsnapshot.get("vmSnapshot");
			System.out.println("VM volume 부분 : " + listvmsnapshot);
			model.addAttribute("vmsnapshotlist", listvmsnapshot);
		}

		// //VolumeMetrics 부분
		api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output3 = api.getResultFromRequest(command3, session);
		System.out.println(output3);
		JSONObject object_vmmetrics = new JSONObject(output3);
		// //오류발생 A JSONObject text must begin with '{' at 1 [character 2 line 1]] with
		// root cause
		// // api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
		// apikey.getBaseURL());를 새로 선언해 주어야 된다.
		object_vmmetrics = object_vmmetrics.getJSONObject("listvolumesmetricsresponse");
		if (!object_vmmetrics.isNull("volume")) {
			JSONArray listvmmetrics = (JSONArray) object_vmmetrics.get("volume");
			System.out.println("metrics 부분 : " + listvmmetrics);
			model.addAttribute("vmmetricslist", listvmmetrics);
		}

		// Snapshot 부분
		api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output4 = api.getResultFromRequest(command4, session);
		System.out.println(output4);
		JSONObject object_snapshot = new JSONObject(output4);
		// 오류발생 A JSONObject text must begin with '{' at 1 [character 2 line 1]] with
		// root cause
		// api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
		// apikey.getBaseURL());를 새로 선언해 주어야 된다.
		object_snapshot = object_snapshot.getJSONObject("listsnapshotsresponse");
		System.out.println("snapshot Object 부분 : " + object_snapshot);

		if (!object_snapshot.isNull("snapshot")) {
			JSONArray listsnapshot = (JSONArray) object_snapshot.get("snapshot");
			System.out.println("snapshot 부분 : " + listsnapshot);
			model.addAttribute("snapshotlist", listsnapshot);
		}

		// Storage Event 부분
		api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		String output5 = api.getResultFromRequest(command5, session);
		System.out.println(output4);
		JSONObject object_evnet = new JSONObject(output5);
		// 오류발생 A JSONObject text must begin with '{' at 1 [character 2 line 1]] with
		// root cause
		// api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(),
		// apikey.getBaseURL());를 새로 선언해 주어야 된다.

		object_evnet = object_evnet.getJSONObject("listeventsresponse");

		// System.out.println(" Event : " + object_evnet);
		JSONArray listEvent = (JSONArray) object_evnet.get("event");
		JSONArray storageEvent = new JSONArray();
		// JSONArray listStorageEvent = new JSONArray();
		int size = listEvent.length();
		int index = 0;
		String type;

		while (index < size) {
			type = listEvent.getJSONObject(index).getString("type");
			String isVolume = type.substring(0, 6);
			// System.out.println(x);

			if (isVolume.equals("VOLUME")) {
				// System.out.println(listEvent.getJSONObject(index));
				storageEvent.put(listEvent.getJSONObject(index));
			}

			index += 1;
		}
		System.out.println(storageEvent);

		model.addAttribute("storageEventList", storageEvent);

		return "admin/storage";
	}

	// storage-volume상세 페이지
	@RequestMapping(value = "/admin/storageVolumesContents", method = RequestMethod.POST)
	public String storageVolumesContents(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to storage Volume Contents");
		String id = request.getParameter("storageid");
		apiDTO apikey = null;
		String command = "listVolumes&id=" + id;
		JSONObject result = null;
		try {
			apikey = api_service.listAPI("OM-admin");
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command, session);
			System.out.println(output);
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listvolumesresponse");
			System.out.println(obj);
			JSONArray arr = (JSONArray) obj.get("volume");
			System.out.println(arr);
			result = arr.getJSONObject(0);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("storagelist", result);
		return "admin/storageVolumesContents";
	}

	// storage- Snapshot 상세 페이지
	@RequestMapping(value = "/admin/storageSnapshotContents", method = RequestMethod.POST)
	public String storageSnapshotContents(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to storage Snapshot Contents");
		String id = request.getParameter("snapshotid");

		// 자바스크립트의 clicked 함수에서
		// $.redirect('<%=cp%>/admin/storageVmsnapshotContents',
		// {'vmsnapshotid':vmsnapshotid});
		// 받은 값을 String id로 받는다.

		apiDTO apikey = null;
		String command = "listSnapshots&id=" + id;
		System.out.println("command");
		System.out.println(command);
		JSONObject result = null;
		try {
			apikey = api_service.listAPI("OM-admin");
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command, session); // 여기서 특정아이디만 가져오는게 아니라 전체를 가져온다.
			System.out.println(output);
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listsnapshotsresponse");
			System.out.println(obj);
			JSONArray arr = (JSONArray) obj.get("snapshot");
			System.out.println(arr);
			result = arr.getJSONObject(0);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("snapshotlist", result);
		return "admin/storageSnapshotContents";
	}

	@RequestMapping(value = "/apivolumeEvent", method = RequestMethod.POST)
	public void apivolumeEvent(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("api_resizeVolume");
		apiDTO apikey = null;
		String command = request.getParameter("test");
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command, session);
		JSONObject object_evnet = new JSONObject(output);
		object_evnet = object_evnet.getJSONObject("listeventsresponse");
		JSONArray listEvent = (JSONArray) object_evnet.get("event");
		JSONArray storageEvent = new JSONArray();
		int size = listEvent.length();
		int index = 0;
		String type;

		while (index < size) {
			type = listEvent.getJSONObject(index).getString("type");
			String isVolume = type.substring(0, 6);
			// System.out.println(x);

			if (isVolume.equals("VOLUME")) {
				// System.out.println(listEvent.getJSONObject(index));
				storageEvent.put(listEvent.getJSONObject(index));
			}

			index += 1;
		}

		PrintWriter out = response.getWriter();
		System.out.println("output : " + output);
		out.print(storageEvent);
		out.flush();
		out.close();
	}

	// 영기 추가 storage-VM Snapshot
	@RequestMapping(value = "/admin/storageVmsnapshotContents", method = RequestMethod.POST)
	public String storageVmsnapshotContents(Locale locale, Model model, HttpServletResponse response,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("go to storage VM Snapshot Contents");
		String id = request.getParameter("vmsnapshotid");

		// 자바스크립트의 clicked 함수에서
		// $.redirect('<%=cp%>/admin/storageVmsnapshotContents',
		// {'vmsnapshotid':vmsnapshotid});
		// 받은 값을 String id로 받는다.

		apiDTO apikey = null;
		String command = "listVMSnapshot&id=" + id;
		System.out.println("command");
		System.out.println(command);
		JSONObject result = null;
		try {
			apikey = api_service.listAPI("OM-admin");
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command, session); // 여기서 특정아이디만 가져오는게 아니라 전체를 가져온다.
			System.out.println(output);
			JSONObject obj = new JSONObject(output);
			obj = obj.getJSONObject("listvmsnapshotresponse");
			System.out.println(obj);
			JSONArray arr = (JSONArray) obj.get("vmSnapshot");
			System.out.println(arr);
			result = arr.getJSONObject(0);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("vmsnapshotlist", result);
		return "admin/storageVmsnapshotContents";
	}
	//////////////////////////
	// 영기 추가 끝
	//////////////////////////

	// 이민재 추가 start
	// 민재 queryAsyncJobResult
	@RequestMapping(value = "/admin/infra/queryAsyncJobResult", method = RequestMethod.GET)
	public void apiQueryAsyncJobResult(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiQueryAsyncJobResult");
		apiDTO apikey = null;
		String command = "queryAsyncJobResult";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listHypervisors
	@RequestMapping(value = "/admin/infra/listHypervisors", method = RequestMethod.GET)
	public void apiListHypervisors(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListHypervisors");
		apiDTO apikey = null;
		String command = "listHypervisors";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listNetworkOfferings
	@RequestMapping(value = "/admin/infra/listNetworkOfferings", method = RequestMethod.GET)
	public void apiListNetworkOffering(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiListNetworkOffering");
		apiDTO apikey = null;
		String command = "listNetworkOfferings";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listDomains
	@RequestMapping(value = "/admin/infra/listDomains", method = RequestMethod.GET)
	public void apiListDomains(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListDomains");
		apiDTO apikey = null;
		String command = "listDomains";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listNetworkServiceProviders
	@RequestMapping(value = "/admin/infra/listNetworkServiceProviders", method = RequestMethod.GET)
	public void apiListNetworkServiceProviders(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiListNetworkServiceProviders");
		apiDTO apikey = null;
		String command = "listNetworkServiceProviders";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listVirtualRouterElements
	@RequestMapping(value = "/admin/infra/listVirtualRouterElements", method = RequestMethod.GET)
	public void apiListVirtualRouterElements(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiListVirtualRouterElements");
		apiDTO apikey = null;
		String command = "listVirtualRouterElements";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listImageStores
	@RequestMapping(value = "/admin/infra/listImageStores", method = RequestMethod.GET)
	public void apiListImageStores(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListImageStores");
		apiDTO apikey = null;
		String command = "listImageStores";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listStorageTags
	@RequestMapping(value = "/admin/infra/listStorageTags", method = RequestMethod.GET)
	public void apiListStorageTags(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListStorageTags");
		apiDTO apikey = null;
		String command = "listStorageTags";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listStorageProviders
	@RequestMapping(value = "/admin/infra/listStorageProviders", method = RequestMethod.GET)
	public void apiListStorageProviders(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiListStorageProviders");
		apiDTO apikey = null;
		String command = "listStorageProviders";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listConfigurations
	@RequestMapping(value = "/admin/infra/listConfigurations", method = RequestMethod.GET)
	public void apiListConfigurations(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiListConfigurations");
		apiDTO apikey = null;
		String command = "listConfigurations";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listZones
	@RequestMapping(value = "/admin/infra/listZones", method = RequestMethod.GET)
	public void apiListZones(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListZones");
		apiDTO apikey = null;
		String command = "listZones";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listPods
	@RequestMapping(value = "/admin/infra/listPods", method = RequestMethod.GET)
	public void apiListPods(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListPods");
		apiDTO apikey = null;
		String command = "listPods";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listClusters
	@RequestMapping(value = "/admin/infra/listClusters", method = RequestMethod.GET)
	public void apiListClusters(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListClusters");
		apiDTO apikey = null;
		String command = "listClusters";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listHosts
	@RequestMapping(value = "/admin/infra/listHosts", method = RequestMethod.GET)
	public void apiListHosts(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListHosts");
		apiDTO apikey = null;
		String command = "listHosts";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-listStoragePools
	@RequestMapping(value = "/admin/infra/listStoragePools", method = RequestMethod.GET)
	public void apiListStoragePools(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListStoragePools");
		apiDTO apikey = null;
		String command = "listStoragePools";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listDedicatedZones
	@RequestMapping(value = "/admin/infra/listDedicatedZones", method = RequestMethod.GET)
	public void apiListDedicatedZones(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListDedicatedZones");
		apiDTO apikey = null;
		String command = "listDedicatedZones";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listDedicatedPods
	@RequestMapping(value = "/admin/infra/listDedicatedPods", method = RequestMethod.GET)
	public void apiListDedicatedPods(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListDedicatedPods");
		apiDTO apikey = null;
		String command = "listDedicatedPods";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-listDedicatedClusters
	@RequestMapping(value = "/admin/infra/listDedicatedClusters", method = RequestMethod.GET)
	public void apiListDedicatedClusters(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListDedicatedClusters");
		apiDTO apikey = null;
		String command = "listDedicatedClusters";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listDedicatedHosts
	@RequestMapping(value = "/admin/infra/listDedicatedHosts", method = RequestMethod.GET)
	public void apiListDedicatedHosts(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListDedicatedHosts");
		apiDTO apikey = null;
		String command = "listDedicatedHosts";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listVmwareDcs
	@RequestMapping(value = "/admin/infra/listVmwareDcs", method = RequestMethod.GET)
	public void apiListVmwareDcs(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListVmwareDcs");
		apiDTO apikey = null;
		String command = "listVmwareDcs";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-listApis
	@RequestMapping(value = "/admin/infra/listApis", method = RequestMethod.GET)
	public void apiListApis(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListApis");
		apiDTO apikey = null;
		String command = "listApis";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-listSystemVms
	@RequestMapping(value = "/admin/infra/listSystemVms", method = RequestMethod.GET)
	public void apiListSystemVms(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListSystemVms");
		apiDTO apikey = null;
		String command = "listSystemVms";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	
	// 민재 infra-listServiceOfferings
	@RequestMapping(value = "/admin/infra/listServiceOfferings", method = RequestMethod.GET)
	public void apiListServiceOfferings(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListServiceOfferings");
		apiDTO apikey = null;
		String command = "listServiceOfferings";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-listRouters
	@RequestMapping(value = "/admin/infra/listRouters", method = RequestMethod.GET)
	public void apiListRouters(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiListRouters");
		apiDTO apikey = null;
		String command = "listRouters";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-clustersRedirect
	@RequestMapping(value = "/admin/infra/clustersRedirect", method = RequestMethod.GET)
	public String ClustersRedirect(Locale locale, Model model, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("clustersRedirect");
		apiDTO apikey = null;
		String command = "listClusters";
		String param = request.getParameter("param");
		System.out.println(command + param);
		System.out.println(param);
		
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listclustersresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("cluster");
		}
		System.out.println(arr);
	
		model.addAttribute("clusterlist", arr);
		return "admin/infra_cluster";
	}
	
	// 민재 infra-hostsRedirect
	@RequestMapping(value = "/admin/infra/hostsRedirect", method = RequestMethod.GET)
	public String hostsRedirect(Locale locale, Model model, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("hostsRedirect");
		apiDTO apikey = null;
		String command = "listHosts&hypervisor=XenServer";
		String param = request.getParameter("param");
		System.out.println(command + param);
		System.out.println(param);
		
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listhostsresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("host");
		}
		System.out.println(arr);
	
		model.addAttribute("hostlist", arr);
		return "admin/infra_host";
	}
		
	// 민재 infra-routersRedirect
	@RequestMapping(value = "/admin/infra/routersRedirect", method = RequestMethod.GET)
	public String routersRedirect(Locale locale, Model model, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("routersRedirect");
		apiDTO apikey = null;
		String command = "listRouters";
		String param = request.getParameter("param");
		System.out.println(command + param);

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listroutersresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("router");
		}
		System.out.println(arr);
	
		model.addAttribute("routerlist", arr);
		return "admin/infra_routers";
	}

	// 민재 infra-systemVmsRedirect
	@RequestMapping(value = "/admin/infra/systemVmsRedirect", method = RequestMethod.GET)
	public String systemVmsRedirect(Locale locale, Model model, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("systemVmsRedirect");
		apiDTO apikey = null;
		String command = "listSystemVms";
		String param = request.getParameter("param");
		System.out.println(command + param);

		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);
		JSONObject obj = new JSONObject(output);
		System.out.println(obj);
		obj = obj.getJSONObject("listroutersresponse");
		// obj = obj.getJSONObject("user");
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("router");
		}
		System.out.println(arr);
	
		model.addAttribute("routerlist", arr);
		return "admin/infra_routers";
	}
	
	// 민재 infra-networksRedirect
	@RequestMapping(value = "/admin/infra/networksRedirect", method = RequestMethod.GET)
	public String networksRedirect(Locale locale, Model model, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("networksRedirect");
		apiDTO apikey = null;
		String command = "listNetworks&listall=true";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);
		JSONObject obj = new JSONObject(output);
		obj = obj.getJSONObject("listnetworksresponse");
		// obj = obj.getJSONObject("user");
		// System.out.println(obj);
		JSONArray arr = null;
		if (obj.length() > 0) {
			arr = (JSONArray) obj.get("network");
		}
		System.out.println(arr);
		model.addAttribute("networklist", arr);
		return "admin/networks";
	}
	
	// 민재 infra-dedicateZone
	@RequestMapping(value = "/admin/infra/dedicateZone", method = RequestMethod.GET)
	public void apiDedicateZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDedicateZone");
		apiDTO apikey = null;
		String command = "dedicateZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-dedicatePod
	@RequestMapping(value = "/admin/infra/dedicatePod", method = RequestMethod.GET)
	public void apiDedicatePod(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDedicatePod");
		apiDTO apikey = null;
		String command = "dedicatePod";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-dedicateCluster
	@RequestMapping(value = "/admin/infra/dedicateCluster", method = RequestMethod.GET)
	public void apiDedicateCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDedicateCluster");
		apiDTO apikey = null;
		String command = "dedicateCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-dedicateHost
	@RequestMapping(value = "/admin/infra/dedicateHost", method = RequestMethod.GET)
	public void apiDedicateHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDedicateHost");
		apiDTO apikey = null;
		String command = "dedicateHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-releaseDedicatedZone
	@RequestMapping(value = "/admin/infra/releaseDedicatedZone", method = RequestMethod.GET)
	public void apiReleaseDedicatedZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiReleaseDedicatedZone");
		apiDTO apikey = null;
		String command = "releaseDedicatedZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-releaseDedicatedPod
	@RequestMapping(value = "/admin/infra/releaseDedicatedPod", method = RequestMethod.GET)
	public void apiReleaseDedicatedPod(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiReleaseDedicatedPod");
		apiDTO apikey = null;
		String command = "releaseDedicatedPod";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-releaseDedicatedCluster
		@RequestMapping(value = "/admin/infra/releaseDedicatedCluster", method = RequestMethod.GET)
		public void apiReleaseDedicatedCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
				HttpSession session) throws Exception {
			logger.info("apiReleaseDedicatedCluster");
			apiDTO apikey = null;
			String command = "releaseDedicatedCluster";
			String param = request.getParameter("param");
			System.out.println(command + param);
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command + param, session);

			PrintWriter out = response.getWriter();
			out.print(output);
			out.flush();
			out.close();
		}

	// 민재 infra-releaseDedicatedHost
		@RequestMapping(value = "/admin/infra/releaseDedicatedHost", method = RequestMethod.GET)
		public void apiReleaseDedicatedHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
				HttpSession session) throws Exception {
			logger.info("apiReleaseDedicatedHost");
			apiDTO apikey = null;
			String command = "releaseDedicatedHost";
			String param = request.getParameter("param");
			System.out.println(command + param);
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command + param, session);

			PrintWriter out = response.getWriter();
			out.print(output);
			out.flush();
			out.close();
		}
	// 민재 infra-createZone
	@RequestMapping(value = "/admin/infra/createZone", method = RequestMethod.GET)
	public void apiCreateZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiCreateZone");
		apiDTO apikey = null;
		String command = "createZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-create_physicalNetwork
	@RequestMapping(value = "/admin/infra/createPhysicalNetwork", method = RequestMethod.GET)
	public void apiCreatePhysicalNetwork(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreatePhysicalNetwork");
		apiDTO apikey = null;
		String command = "createPhysicalNetwork";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createNetwork
	@RequestMapping(value = "/admin/infra/createNetwork", method = RequestMethod.GET)
	public void apiCreateNetwork(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiCreateNetwork");
		apiDTO apikey = null;
		String command = "createNetwork";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createVlanIpRange
	@RequestMapping(value = "/admin/infra/createVlanIpRange", method = RequestMethod.GET)
	public void apiCreateVlanIpRange(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreateVlanIpRange");
		apiDTO apikey = null;
		String command = "createVlanIpRange";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createStorageNetworkIpRange
	@RequestMapping(value = "/admin/infra/createStorageNetworkIpRange", method = RequestMethod.GET)
	public void apiCreateStorageNetworkIpRange(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreateStorageNetworkIpRange");
		apiDTO apikey = null;
		String command = "createStorageNetworkIpRange";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createPod
	@RequestMapping(value = "/admin/infra/createPod", method = RequestMethod.GET)
	public void apiCreatePod(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiCreatePod");
		apiDTO apikey = null;
		String command = "createPod";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createStoragePool
	@RequestMapping(value = "/admin/infra/createStoragePool", method = RequestMethod.GET)
	public void apiCreateStoragePool(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreateStoragePool");
		apiDTO apikey = null;
		String command = "createStoragePool";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-createSecondaryStagingStore
	@RequestMapping(value = "/admin/infra/createSecondaryStagingStore", method = RequestMethod.GET)
	public void apiCreateSecondaryStagingStore(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCreateSecondaryStagingStore");
		apiDTO apikey = null;
		String command = "createSecondaryStagingStore";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addTraficType
	@RequestMapping(value = "/admin/infra/addTrafficType", method = RequestMethod.GET)
	public void apiAddTrafficType(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAddTrafficType");
		apiDTO apikey = null;
		String command = "addTrafficType";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addNetworkServiceProvider
	@RequestMapping(value = "/admin/infra/addNetworkServiceProvider", method = RequestMethod.GET)
	public void apiAddNetworkServiceProvider(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiAddNetworkServiceProvider");
		apiDTO apikey = null;
		String command = "addNetworkServiceProvider";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addNetscalerLoadBalancer
	@RequestMapping(value = "/admin/infra/addNetscalerLoadBalancer", method = RequestMethod.GET)
	public void apiAddNetscalerLoadBalancer(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiAddNetscalerLoadBalancer");
		apiDTO apikey = null;
		String command = "addNetscalerLoadBalancer";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addCluster
	@RequestMapping(value = "/admin/infra/addCluster", method = RequestMethod.GET)
	public void apiAddCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAddCluster");
		apiDTO apikey = null;
		String command = "addCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addHost
	@RequestMapping(value = "/admin/infra/addHost", method = RequestMethod.GET)
	public void apiAddHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAddHost");
		apiDTO apikey = null;
		String command = "addHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addImageStore
	@RequestMapping(value = "/admin/infra/addImageStore", method = RequestMethod.GET)
	public void apiAddImageStore(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAddImageStore");
		apiDTO apikey = null;
		String command = "addImageStore";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-addVmwareDc
	@RequestMapping(value = "/admin/infra/addVmwareDc", method = RequestMethod.GET)
	public void apiAddVmwareDc(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiAddVmwareDc");
		apiDTO apikey = null;
		String command = "addImageStore";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-updatePhysicalNetwork
	@RequestMapping(value = "/admin/infra/updatePhysicalNetwork", method = RequestMethod.GET)
	public void apiUpdatePhysicalNetwork(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiUpdatePhysicalNetwork");
		apiDTO apikey = null;
		String command = "updatePhysicalNetwork";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-updateNetworkServiceProvider
	@RequestMapping(value = "/admin/infra/updateNetworkServiceProvider", method = RequestMethod.GET)
	public void apiUpdateNetworkServiceProvider(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiUpdateNetworkServiceProvider");
		apiDTO apikey = null;
		String command = "updateNetworkServiceProvider";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-updateConfiguration
	@RequestMapping(value = "/admin/infra/updateConfiguration", method = RequestMethod.GET)
	public void apiUpdateConfiguration(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiUpdateConfiguration");
		apiDTO apikey = null;
		String command = "updateConfiguration";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-updateZone
	@RequestMapping(value = "/admin/infra/updateZone", method = RequestMethod.GET)
	public void apiUpdateZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiUpdateZone");
		apiDTO apikey = null;
		String command = "updateZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-updatePod
	@RequestMapping(value = "/admin/infra/updatePod", method = RequestMethod.GET)
	public void apiUpdatePod(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiUpdatePod");
		apiDTO apikey = null;
		String command = "updatePod";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-updateCluster
	@RequestMapping(value = "/admin/infra/updateCluster", method = RequestMethod.GET)
	public void apiUpdateCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiUpdateCluster");
		apiDTO apikey = null;
		String command = "updateCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-updateHost
	@RequestMapping(value = "/admin/infra/updateHost", method = RequestMethod.GET)
	public void apiUpdateHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiUpdateHost");
		apiDTO apikey = null;
		String command = "updateHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableHAForZone
	@RequestMapping(value = "/admin/infra/enableHAForZone", method = RequestMethod.GET)
	public void apiEnableHAForZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableHAForZone");
		apiDTO apikey = null;
		String command = "enableHAForZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableHAForCluster
	@RequestMapping(value = "/admin/infra/enableHAForCluster", method = RequestMethod.GET)
	public void apiEnableHAForCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableHAForCluster");
		apiDTO apikey = null;
		String command = "enableHAForCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableHAForHost
	@RequestMapping(value = "/admin/infra/enableHAForHost", method = RequestMethod.GET)
	public void apiEnableHAForHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableHAForHost");
		apiDTO apikey = null;
		String command = "enableHAForHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableOutOfBandManagementForZone
	@RequestMapping(value = "/admin/infra/enableOutOfBandManagementForZone", method = RequestMethod.GET)
	public void apiEnableOutOfBandManagementForZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableOutOfBandManagementForZone");
		apiDTO apikey = null;
		String command = "enableOutOfBandManagementForZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableOutOfBandManagementForCluster
	@RequestMapping(value = "/admin/infra/enableOutOfBandManagementForCluster", method = RequestMethod.GET)
	public void apiEnableOutOfBandManagementForCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableOutOfBandManagementForCluster");
		apiDTO apikey = null;
		String command = "enableOutOfBandManagementForCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableOutOfBandManagementForHost
	@RequestMapping(value = "/admin/infra/enableOutOfBandManagementForHost", method = RequestMethod.GET)
	public void apiEnableOutOfBandManagementForHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableOutOfBandManagementForHost");
		apiDTO apikey = null;
		String command = "enableOutOfBandManagementForHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-enableStorageMaintenance
	@RequestMapping(value = "/admin/infra/enableStorageMaintenance", method = RequestMethod.GET)
	public void apiEnableStorageMaintenance(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiEnableStorageMaintenance");
		apiDTO apikey = null;
		String command = "enableStorageMaintenance";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableOutOfBandManagementForZone
	@RequestMapping(value = "/admin/infra/disableOutOfBandManagementForZone", method = RequestMethod.GET)
	public void apiDisableOutOfBandManagementForZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDisableOutOfBandManagementForZone");
		apiDTO apikey = null;
		String command = "disableOutOfBandManagementForZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableOutOfBandManagementForCluster
	@RequestMapping(value = "/admin/infra/disableOutOfBandManagementForCluster", method = RequestMethod.GET)
	public void apiDisableOutOfBandManagementForCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDisableOutOfBandManagementForCluster");
		apiDTO apikey = null;
		String command = "disableOutOfBandManagementForCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableOutOfBandManagementForHost
	@RequestMapping(value = "/admin/infra/disableOutOfBandManagementForHost", method = RequestMethod.GET)
	public void apiDisableOutOfBandManagementForHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDisableOutOfBandManagementForHost");
		apiDTO apikey = null;
		String command = "disableOutOfBandManagementForHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableHAForZone
	@RequestMapping(value = "/admin/infra/disableHAForZone", method = RequestMethod.GET)
	public void apiDisableHAForZone(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDisableHAForZone");
		apiDTO apikey = null;
		String command = "disableHAForZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableHAForCluster
	@RequestMapping(value = "/admin/infra/disableHAForCluster", method = RequestMethod.GET)
	public void apiDisableHAForCluster(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiDisableHAForCluster");
		apiDTO apikey = null;
		String command = "disableHAForCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
	
	// 민재 infra-disableHAForHost
		@RequestMapping(value = "/admin/infra/disableHAForHost", method = RequestMethod.GET)
		public void apiDisableHAForHost(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
				HttpSession session) throws Exception {
			logger.info("apiDisableHAForHost");
			apiDTO apikey = null;
			String command = "disableHAForHost";
			String param = request.getParameter("param");
			System.out.println(command + param);
			try {
				apikey = api_service.listAPI("OM-admin");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
			String output = api.getResultFromRequest(command + param, session);

			PrintWriter out = response.getWriter();
			out.print(output);
			out.flush();
			out.close();
		}	
	
	// 민재 infra-configureHAForHost
	@RequestMapping(value = "/admin/infra/configureHAForHost", method = RequestMethod.GET)
	public void apiConfigureHAForHost(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiConfigureHAForHost");
		apiDTO apikey = null;
		String command = "configureHAForHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-configureVirtualRouterElement
	@RequestMapping(value = "/admin/infra/configureVirtualRouterElement", method = RequestMethod.GET)
	public void apiConfigureVirtualRouterElement(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiConfigureVirtualRouterElement");
		apiDTO apikey = null;
		String command = "configureVirtualRouterElement";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-configureOutOfBandManagement
	@RequestMapping(value = "/admin/infra/configureOutOfBandManagement", method = RequestMethod.GET)
	public void apiConfigureOutOfBandManagement(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiConfigureOutOfBandManagement");
		apiDTO apikey = null;
		String command = "configureOutOfBandManagement";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-deleteZone
	@RequestMapping(value = "/admin/infra/deleteZone", method = RequestMethod.GET)
	public void apiDeleteZone(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeleteZone");
		apiDTO apikey = null;
		String command = "deleteZone";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-deletePod
	@RequestMapping(value = "/admin/infra/deletePod", method = RequestMethod.GET)
	public void apiDeletePod(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeletePod");
		apiDTO apikey = null;
		String command = "deletePod";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-deleteCluster
	@RequestMapping(value = "/admin/infra/deleteCluster", method = RequestMethod.GET)
	public void apiDeleteCluster(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeleteCluster");
		apiDTO apikey = null;
		String command = "deleteCluster";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-deleteHost
	@RequestMapping(value = "/admin/infra/deleteHost", method = RequestMethod.GET)
	public void apiDeleteHost(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeleteHost");
		apiDTO apikey = null;
		String command = "deleteHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
		
	// 민재 infra-deleteImageStore
	@RequestMapping(value = "/admin/infra/deleteImageStore", method = RequestMethod.GET)
	public void apiDeleteImageStore(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDeleteImageStore");
		apiDTO apikey = null;
		String command = "deleteImageStore";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-removeVmwareDc
	@RequestMapping(value = "/admin/infra/removeVmwareDc", method = RequestMethod.GET)
	public void apiRemoveVmwareDc(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiRemoveVmwareDc");
		apiDTO apikey = null;
		String command = "removeVmwareDc";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-prepareHostForMaintenance
	@RequestMapping(value = "/admin/infra/prepareHostForMaintenance", method = RequestMethod.GET)
	public void apiPrepareHostForMaintenance(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiPrepareHostForMaintenance");
		apiDTO apikey = null;
		String command = "prepareHostForMaintenance";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-cancelHostMaintenance
	@RequestMapping(value = "/admin/infra/cancelHostMaintenance", method = RequestMethod.GET)
	public void apiCancelHostMaintenance(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiCancelHostMaintenance");
		apiDTO apikey = null;
		String command = "cancelHostMaintenance";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-cancelStorageMaintenance
	@RequestMapping(value = "/admin/infra/cancelStorageMaintenance", method = RequestMethod.GET)
	public void apiCancelStorageMaintenance(Locale locale, Model model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		logger.info("apiCancelStorageMaintenance");
		apiDTO apikey = null;
		String command = "cancelStorageMaintenance";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}	
		
	// 민재 infra-reconnectHost
	@RequestMapping(value = "/admin/infra/reconnectHost", method = RequestMethod.GET)
	public void apiReconnectHost(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiReconnectHost");
		apiDTO apikey = null;
		String command = "reconnectHost";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-issueOutOfBandManagementPowerAction
	@RequestMapping(value = "/admin/infra/issueOutOfBandManagementPowerAction", method = RequestMethod.GET)
	public void apiIssueOutOfBandManagementPowerAction(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiIssueOutOfBandManagementPowerAction");
		apiDTO apikey = null;
		String command = "issueOutOfBandManagementPowerAction";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-changeOutOfBandManagementPassword
	@RequestMapping(value = "/admin/infra/changeOutOfBandManagementPassword", method = RequestMethod.GET)
	public void apiChangeOutOfBandManagementPassword(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiChangeOutOfBandManagementPassword");
		apiDTO apikey = null;
		String command = "changeOutOfBandManagementPassword";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-startSystemVm
	@RequestMapping(value = "/admin/infra/startSystemVm", method = RequestMethod.GET)
	public void apiStartSystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiStartSystemVm");
		apiDTO apikey = null;
		String command = "startSystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-stopSystemVm
	@RequestMapping(value = "/admin/infra/stopSystemVm", method = RequestMethod.GET)
	public void apiStopSystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiStopSystemVm");
		apiDTO apikey = null;
		String command = "stopSystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-rebootSystemVm
	@RequestMapping(value = "/admin/infra/rebootSystemVm", method = RequestMethod.GET)
	public void apiRebootSystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiRebootSystemVm");
		apiDTO apikey = null;
		String command = "rebootSystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	// 민재 infra-destroySystemVm
	@RequestMapping(value = "/admin/infra/destroySystemVm", method = RequestMethod.GET)
	public void apiDestroySystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiDestroySystemVm");
		apiDTO apikey = null;
		String command = "destroySystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-migrateSystemVm
	@RequestMapping(value = "/admin/infra/migrateSystemVm", method = RequestMethod.GET)
	public void apiMigrateSystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiMigrateSystemVm");
		apiDTO apikey = null;
		String command = "migrateSystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-findHostsForMigration
	@RequestMapping(value = "/admin/infra/findHostsForMigration", method = RequestMethod.GET)
	public void apiFindHostsForMigration(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiFindHostsForMigration");
		apiDTO apikey = null;
		String command = "findHostsForMigration";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	
	// 민재 infra-scaleSystemVm
	@RequestMapping(value = "/admin/infra/scaleSystemVm", method = RequestMethod.GET)
	public void apiScaleSystemVm(Locale locale, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		logger.info("apiScaleSystemVm");
		apiDTO apikey = null;
		String command = "scaleSystemVm";
		String param = request.getParameter("param");
		System.out.println(command + param);
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());
		String output = api.getResultFromRequest(command + param, session);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}
	// 이민재 추가 end

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 김규아 추가
	@RequestMapping(value = "/admin/billing", method = RequestMethod.GET)
	public String billing(Locale locale, Model model) throws Exception {
		logger.info("Billing");

		ArrayList<BillingDTO> BillingList = billing_service.selectBilling();
		model.addAttribute("BillingList", BillingList);

		ArrayList<ProductDTO> CloudList = product_service.selectCloudView();
		model.addAttribute("CloudList", CloudList);

		ArrayList<ProductDTO> CloudOptionList = product_service.selectOptionView();
		model.addAttribute("CloudOptionList", CloudOptionList);

		ArrayList<ProductDTO> HPCSWList = product_service.selectHPCSWView();
		model.addAttribute("HPCSWList", HPCSWList);

		ArrayList<ProductDTO> GPUList = product_service.selectGPUView();
		model.addAttribute("GPUList", GPUList);

		ArrayList<InstanceDTO> VMList = instance_service.selectInstance();
		model.addAttribute("VMList", VMList);

		return "/admin/billing";
	}

	@RequestMapping(value = "/admin/billinginfo", method = RequestMethod.POST)
	public void billinginfo(HttpServletRequest request, HttpServletResponse response) throws Exception {

		logger.info("billinginfo");

		int Grossturnover = billing_service.Grossturnover();
		int Salesofthisyear = billing_service.Salesofthisyear();
		int Salesofthismonth = billing_service.Salesofthismonth();
		int Depositamount = billing_service.Depositamount();

		billing_service.Automaticrenewal();
		// billing_service.Automaticrenewalvm();

		JSONObject outputObject = new JSONObject();
		outputObject.put("Grossturnover", Grossturnover);
		outputObject.put("Salesofthisyear", Salesofthisyear);
		outputObject.put("Salesofthismonth", Salesofthismonth);
		outputObject.put("Depositamount", Depositamount);

		PrintWriter out = response.getWriter();
		out.print(outputObject);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/addBilling", method = RequestMethod.POST)
	public String addBilling(HttpServletRequest request, BillingDTO dto) throws Exception {
		logger.info("addBilling");

		String modifyNum = request.getParameter("modifyNum");
		System.out.println("modifyNum : " + modifyNum);

		try {
			if (modifyNum == null || modifyNum.trim().equals("")) {
				billing_service.insertBilling(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum));
				billing_service.updateBilling(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return "redirect:/admin/billing";
	}

	@RequestMapping(value = "/admin/getBillingData", method = RequestMethod.POST)
	public void getBillingData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("getBillingData");

		String num = request.getParameter("num");
		System.out.println("num : " + num);

		BillingDTO dto = null;
		try {
			dto = billing_service.selectBillingNum(num);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dto.toString());

		JSONObject outputObject = new JSONObject();
		outputObject.put("email", dto.getEmail());
		outputObject.put("cname", dto.getCname());
		outputObject.put("oname", dto.getOname());
		outputObject.put("count", dto.getCount());
		outputObject.put("total", dto.getTotal());
		outputObject.put("hname", dto.getHname());
		outputObject.put("gname", dto.getGname());
		outputObject.put("endday", dto.getEndday());

		// ajax로 받는 데이터에서 한글 깨져서, <% %>안에 똑같이 써줬는데 무용지물이었음 이미 로드된 데이터에 삽입하는거라서 그런가봄
		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(outputObject);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/ChangeStatus", method = RequestMethod.POST)
	public void ChangeStatus(HttpServletRequest request, HttpServletResponse response, BillingDTO dto)
			throws Exception {
		logger.info("ChangeStatus");

		String num = request.getParameter("num");
		String status = request.getParameter("status");

		System.out.println("status : " + status);
		System.out.println("num : " + num);

		String output = billing_service.updateBillingStatus(num, status);
		billing_service.updateconfirm(dto);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	// 수정중
	@RequestMapping(value = "/admin/ChangeStatus2", method = RequestMethod.POST)
	public void ChangeStatus2(HttpServletRequest request, HttpServletResponse response, BillingDTO dto)
			throws Exception {
		logger.info("ChangeStatus2");

		String num = request.getParameter("num");
		String status = request.getParameter("status");
		String instancename = request.getParameter("instancename");

		System.out.println("status : " + status);
		System.out.println("num : " + num);
		System.out.println("instancename : " + instancename);

		String output = billing_service.updateBillingStatus(num, status);
		billing_service.updateunconfirm(dto);

		instance_service.updateunInstance(instancename);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/admin/ChangeStatus3", method = RequestMethod.POST)
	public void ChangeStatus3(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("ChangeStatus3");

		String num = request.getParameter("num");
		String status = request.getParameter("status");

		System.out.println("status : " + status);
		System.out.println("num : " + num);

		String output = billing_service.updateBillingStatus(num, status);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/admin/ChangeStatus4", method = RequestMethod.POST)
	public void ChangeStatus4(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("ChangeStatus4");

		String num = request.getParameter("num");
		String status = request.getParameter("status");
		String instancename = request.getParameter("instancename");

		System.out.println("status : " + status);
		System.out.println("num : " + num);
		System.out.println("instancename : " + instancename);

		String output = billing_service.updateStatusend(num, status);
		instance_service.updateunInstance(instancename);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/vmstart", method = RequestMethod.POST)
	public void vmstart(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("vmstart");

		String vm = request.getParameter("vm");

		System.out.println("vm : " + vm);

		int output = billing_service.vminuse(vm);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/admin/addvm", method = RequestMethod.POST)
	public void addvm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("addvm");

		String num = request.getParameter("num");
		String vm = request.getParameter("vm");
		String instanceuser = request.getParameter("instanceuser");
		String instancename = vm;

		System.out.println("num : " + num);
		System.out.println("vm : " + vm);

		System.out.println("instanceuser : " + instanceuser);
		System.out.println("instancename : " + instancename);

		String output = billing_service.addvm(num, vm);
		instance_service.updateInstance(instanceuser, instancename);

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/payment", method = RequestMethod.GET)
	public String payment(Model model, HttpSession session) throws Exception {
		System.out.println("사용자/이용상품정보페이지");
		String email = (String) session.getAttribute("useremail"); // email 값을 넘겨 쿼리가 실행되게..

		ArrayList<BillingDTO> UserBillingList = billing_service.selectUserBilling(email);
		model.addAttribute("UserBillingList", UserBillingList);

		return "payment";
	}

	/*
	 * @RequestMapping(value = "/admin/checkEmail", method = RequestMethod.POST)
	 * public void checkEmail(HttpServletRequest request, HttpServletResponse
	 * response) throws Exception { String email = request.getParameter("email");
	 * 
	 * PrintWriter out = response.getWriter(); String output = "";
	 * 
	 * if (billing_service.selectBillingEmail(email) == null) { output = "true"; }
	 * else { output = "false"; }
	 * 
	 * out.print(output); out.flush(); out.close(); }
	 */

	@RequestMapping(value = "/admin/addtotal", method = RequestMethod.POST)
	public void addtotal(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String cname = request.getParameter("cname");
		String oname = request.getParameter("oname");
		String hname = request.getParameter("hname");
		String gname = request.getParameter("gname");
		String count = request.getParameter("count");

		int total = billing_service.selectTotal(cname, oname, hname, gname, count);

		PrintWriter out = response.getWriter();
		String output = String.valueOf(total);

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/addplustotal", method = RequestMethod.POST)
	public void addplustotal(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String cname = request.getParameter("cname");
		String oname = request.getParameter("oname");
		String hname = request.getParameter("hname");
		String gname = request.getParameter("gname");
		String pluscount = request.getParameter("pluscount");

		int total = billing_service.selectTotal(cname, oname, hname, gname, pluscount);

		PrintWriter out = response.getWriter();
		String output = String.valueOf(total);

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/addplusday", method = RequestMethod.POST)
	public void addplusday(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String num = request.getParameter("num");
		String endday = request.getParameter("endday");
		String pluscount = request.getParameter("pluscount");

		String day = billing_service.selectPlusday(num, endday, pluscount);

		PrintWriter out = response.getWriter();
		String output = String.valueOf(day);

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/plusday", method = RequestMethod.POST)
	public void plusday(HttpServletRequest request, HttpServletResponse response) throws Exception {
		PrintWriter out = response.getWriter();

		String num = request.getParameter("num");
		String plustotal = request.getParameter("plustotal");
		String pluscount = request.getParameter("pluscount");
		String total = request.getParameter("total");
		String count = request.getParameter("count");
		String endday = request.getParameter("endday");

		String output = billing_service.updateExtension(num, plustotal, pluscount, total, count, endday);

		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/shop/shop", method = RequestMethod.GET)
	public String shop(Model model, HttpSession session) throws Exception {
		logger.info("shop");

		ArrayList<ProductDTO> CloudViewList = product_service.selectCloudView();
		model.addAttribute("CloudViewList", CloudViewList);
		ArrayList<ProductDTO> OptionViewList = product_service.selectOptionView();
		model.addAttribute("OptionViewList", OptionViewList);
		ArrayList<ProductDTO> HPCSWViesList = product_service.selectHPCSWView();
		model.addAttribute("HPCSWViesList", HPCSWViesList);
		ArrayList<ProductDTO> GPUViewist = product_service.selectGPUView();
		model.addAttribute("GPUViewist", GPUViewist);

		return "/shop/shop";
	}

	@RequestMapping(value = "/shop/cloudproduct", method = RequestMethod.GET)
	public String cloudproduct(Locale locale, Model model) throws Exception {
		System.out.println("Cloud상품목록페이지");

		ArrayList<ProductDTO> CloudViewList = product_service.selectCloudView();
		model.addAttribute("CloudViewList", CloudViewList);

		ArrayList<ProductDTO> CloudList = product_service.selectCloudProduct();
		model.addAttribute("CloudList", CloudList);
		ArrayList<ProductDTO> CloudOptionList = product_service.selectOptionProduct();
		model.addAttribute("CloudOptionList", CloudOptionList);

		return "/shop/cloudproduct";
	}

	@RequestMapping(value = "/shop/hpcproduct", method = RequestMethod.GET)
	public String hpcproduct(Locale locale, Model model) throws Exception {
		System.out.println("Option상품목록페이지");

		ArrayList<ProductDTO> HPCSWViesList = product_service.selectHPCSWView();
		model.addAttribute("HPCSWViesList", HPCSWViesList);

		ArrayList<ProductDTO> GPUViewist = product_service.selectGPUView();
		model.addAttribute("GPUViewist", GPUViewist);

		ArrayList<ProductDTO> HPCSWList = product_service.selectHPCSWProduct();
		model.addAttribute("HPCSWList", HPCSWList);
		ArrayList<ProductDTO> GPUList = product_service.selectGPUProduct();
		model.addAttribute("GPUList", GPUList);

		return "/shop/hpcproduct";
	}

	@RequestMapping(value = "/shop/addCloudproduct", method = RequestMethod.POST)
	public String addCloudproduct(HttpServletRequest request, ProductDTO dto) throws Exception {
		logger.info("addCloudproduct");

		String modifyNum = request.getParameter("modifyNum");
		System.out.println("modifyNum : " + modifyNum);
		try {
			if (modifyNum == null || modifyNum.trim().equals("")) {
				product_service.insertCloudProduct(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum));
				product_service.updateCloud(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return "redirect:/shop/cloudproduct";
	}

	@RequestMapping(value = "/shop/addOptionproduct", method = RequestMethod.POST)
	public String addOptionproduct(HttpServletRequest request, ProductDTO dto) throws Exception {
		logger.info("addOptionproduct");

		String modifyNum = request.getParameter("modifyNum2");
		System.out.println("modifyNum : " + modifyNum);
		try {
			if (modifyNum == null || modifyNum.trim().equals("")) {
				product_service.insertOptionProduct(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum));
				product_service.updateCloud(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return "redirect:/shop/cloudproduct";
	}

	@RequestMapping(value = "/shop/addHPCSWproduct", method = RequestMethod.POST)
	public String addHpcswproduct(HttpServletRequest request, ProductDTO dto) throws Exception {
		logger.info("addHPCSWproduct");

		String modifyNum = request.getParameter("modifyNum3");
		System.out.println("modifyNum : " + modifyNum);

		try {
			if (modifyNum == null || modifyNum.trim().equals("")) {
				product_service.insertHPCSWProduct(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum));
				product_service.updateCloud(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return "redirect:/shop/hpcproduct";
	}

	@RequestMapping(value = "/shop/addGPUproduct", method = RequestMethod.POST)
	public String addProduct(HttpServletRequest request, ProductDTO dto) throws Exception {
		logger.info("addGPUproduct");

		String modifyNum = request.getParameter("modifyNum4");
		System.out.println("modifyNum : " + modifyNum);

		try {
			if (modifyNum == null || modifyNum.trim().equals("")) {
				product_service.insertGPUProduct(dto);
			} else {
				dto.setNum(Integer.parseInt(modifyNum));
				product_service.updateCloud(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}

		return "redirect:/shop/hpcproduct";
	}

	@RequestMapping(value = "/shop/deleteCloud", method = RequestMethod.POST)
	public void deleteCloud(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("shop/deleteCloud");

		String num = request.getParameter("num");
		System.out.println(num);

		String result = product_service.deleteCloud(num);

		PrintWriter out = response.getWriter();
		out.print(result);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/shop/getCloudData", method = RequestMethod.POST)
	public void getCloudData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("getCloudData");

		String num = request.getParameter("num");
		System.out.println(num);

		ProductDTO dto = null;
		try {
			dto = product_service.selectCloudNum(num);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dto.toString());

		JSONObject outputObject = new JSONObject();
		outputObject.put("name", dto.getName());
		outputObject.put("info1", dto.getInfo1());
		outputObject.put("info2", dto.getInfo2());
		outputObject.put("info3", dto.getInfo3());
		outputObject.put("info4", dto.getInfo4());
		outputObject.put("price", dto.getPrice());
		outputObject.put("location", dto.getLocation());
		outputObject.put("enrollment", dto.getEnrollment());

		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(outputObject);
		out.flush();
		out.close();
	}

	// 김규아추가
	@RequestMapping(value = "/admin/selectpw", method = RequestMethod.POST)
	public void selectpw(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("selectpw");

		String instancename = request.getParameter("instancename");

		System.out.println("instancename : " + instancename);

		String output = instance_service.selectinstancepwd(instancename);
		System.out.println("pwd : " + output);
		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		out.print(output);
		out.flush();
		out.close();

	}

	@RequestMapping(value = "/uservm", method = RequestMethod.GET)
	public String uservm(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		System.out.println("사용자 VMpage");
		String instancename = request.getParameter("vmname");
		System.out.println("instancename : " + instancename);
		String id = instance_service.selectInstanceid(instancename);
		System.out.println("id : " + id);
		model.addAttribute("id", id);

		return "uservm";
	}

	@RequestMapping(value = "/uservminfo", method = RequestMethod.POST)
	public void uservminfo(Locale locale, Model model, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) throws IOException {
		logger.info("uservminfo");

		apiDTO apikey = null;
		try {
			apikey = api_service.listAPI("OM-admin");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cloudstack_api api = new cloudstack_api(apikey.getApiKey(), apikey.getSecretKey(), apikey.getBaseURL());

		PrintWriter out = response.getWriter();
		String vmid = request.getParameter("vmid");
		String command = "listVirtualMachines&id=" + vmid;

		String output = api.getResultFromRequest(command, session);
		System.out.println("output : " + output);
		// String url = api.get_url();
		out.print(output);
		out.flush();
		out.close();
	}

	@RequestMapping(value = "/admin/chartinfo", method = RequestMethod.POST)
	public void chartinfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("chartinfo");

		int Salesofthismonth = billing_service.Salesofthismonth();
		int Amonthago = billing_service.Amonthago();
		int Twomonthago = billing_service.Twomonthago();
		int Threemonthago = billing_service.Threemonthago();
		int Fourmonthago = billing_service.Fourmonthago();
		int Fivemonthago = billing_service.Fivemonthago();

		JSONObject outputObject = new JSONObject();
		outputObject.put("Salesofthismonth", Salesofthismonth);
		outputObject.put("Amonthago", Amonthago);
		outputObject.put("Twomonthago", Twomonthago);
		outputObject.put("Threemonthago", Threemonthago);
		outputObject.put("Fourmonthago", Fourmonthago);
		outputObject.put("Fivemonthago", Fivemonthago);

		PrintWriter out = response.getWriter();
		out.print(outputObject);
		out.flush();
		out.close();
	}

	// 김규아 추가 여기까지

	// 김규아 수정
	@RequestMapping(value = "/admin/checkEmail", method = RequestMethod.POST)
	public void checkEmail(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String username = request.getParameter("username");
		System.out.println(username);

		PrintWriter out = response.getWriter();

		ArrayList<String> useremaillist = billing_service.searchemail(username);
		System.out.println(useremaillist);

		out.print(useremaillist);
		out.flush();
		out.close();
	}

}
